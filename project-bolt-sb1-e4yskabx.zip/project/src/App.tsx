import React, { useState } from 'react';
import LoginForm from './components/LoginForm';
import RegistrationForm from './components/RegistrationForm';
import Dashboard from './components/Dashboard';
import NewsPage from './components/NewsPage';
import CalendarPage from './components/CalendarPage';
import FeatureBackground from './components/FeatureBackground';
import PlanDetailsPage from './components/PlanDetailsPage';
import PaymentPage from './components/PaymentPage';
import { Building2, Shield } from 'lucide-react';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [showRegistration, setShowRegistration] = useState(false);
  const [showNews, setShowNews] = useState(false);
  const [showCalendar, setShowCalendar] = useState(false);
  const [isMemberVerified, setIsMemberVerified] = useState(false);
  const [showPlanDetails, setShowPlanDetails] = useState(false);
  const [showPayment, setShowPayment] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<{ name: string; price: number; role: string } | null>(null);

  const handleShowPlanDetails = (plan: { name: string; price: number; role: string }) => {
    setSelectedPlan(plan);
    setShowPlanDetails(true);
  };

  const handleShowPayment = () => {
    setShowPlanDetails(false);
    setShowPayment(true);
  };

  if (showPayment && selectedPlan) {
    return (
      <PaymentPage
        plan={selectedPlan}
        role={selectedPlan.role}
        onBack={() => setShowPayment(false)}
        onPaymentComplete={() => {
          setShowPayment(false);
          setIsLoggedIn(true);
        }}
      />
    );
  }

  if (showPlanDetails && selectedPlan) {
    return (
      <PlanDetailsPage
        plan={selectedPlan}
        role={selectedPlan.role}
        onBack={() => setShowPlanDetails(false)}
        onSubscribe={handleShowPayment}
      />
    );
  }

  if (isLoggedIn) {
    if (showNews) {
      return <NewsPage onBack={() => setShowNews(false)} />;
    }

    if (showCalendar) {
      return <CalendarPage onBack={() => setShowCalendar(false)} />;
    }

    return (
      <Dashboard 
        onShowNews={() => setShowNews(true)} 
        onShowCalendar={() => setShowCalendar(true)}
      />
    );
  }

  return (
    <div className="min-h-screen relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-indigo-50 to-blue-100">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(99,102,241,0.15),transparent)] animate-pulse" />
      </div>

      <div className="relative z-10">
        <FeatureBackground />
      </div>

      <div className="relative z-20 min-h-screen flex flex-col items-center justify-center px-4">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-6">
            <div className="relative">
              <Building2 className="h-16 w-16 text-indigo-600" />
              <Shield className="h-8 w-8 text-indigo-800 absolute -bottom-2 -right-2" />
            </div>
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            Bienvenue à AMS CORPIQ
          </h1>
        </div>

        <div className="w-full max-w-xl relative">
          <div className="absolute -top-6 left-1/2 -translate-x-1/2 w-[120%] h-40 bg-white/20 blur-2xl rounded-full" />
          {!showRegistration ? (
            <LoginForm 
              onLoginSuccess={() => setIsLoggedIn(true)}
              onRegisterClick={() => setShowRegistration(true)}
              isMemberVerified={isMemberVerified}
            />
          ) : (
            <RegistrationForm 
              onRegisterSuccess={() => setIsLoggedIn(true)}
              onBackToLogin={() => setShowRegistration(false)}
              onShowPlanDetails={handleShowPlanDetails}
            />
          )}
        </div>
      </div>
    </div>
  );
}

export default App;