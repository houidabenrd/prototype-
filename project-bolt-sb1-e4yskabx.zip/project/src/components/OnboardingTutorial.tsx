import React, { useState } from 'react';
import { X, ChevronRight, ChevronLeft, Check, Building2, Users2, Calendar, Mail, FileText, FileSearch, CreditCard, MessageCircle, Info, HelpCircle, Star, ShoppingCart } from 'lucide-react';
import ServiceTutorialVideo from './ServiceTutorialVideo';

interface ServiceOption {
  id: string;
  title: string;
  description: string;
  icon: React.FC<{ className?: string }>;
  pricing: 'included' | 'limited' | 'pay-per-use';
  price?: number;
  category: string;
  badge: string;
  badgeDescription: string;
}

const serviceOptions: ServiceOption[] = [
  {
    id: 'annonces',
    title: 'Annonces',
    description: 'Publiez et gérez vos offres de location',
    icon: Building2,
    pricing: 'pay-per-use',
    price: 29.99,
    category: 'Cycle de location',
    badge: 'À la pièce',
    badgeDescription: 'Payez uniquement lorsque vous publiez une annonce'
  },
  {
    id: 'enquetes',
    title: 'Enquêtes pré-location',
    description: 'Vérifiez les antécédents des locataires',
    icon: FileSearch,
    pricing: 'pay-per-use',
    price: 49.99,
    category: 'Cycle de location',
    badge: 'À la pièce',
    badgeDescription: 'Payez uniquement lorsque vous effectuez une enquête'
  },
  {
    id: 'baux',
    title: 'Baux électroniques',
    description: 'Créez et gérez vos baux en ligne',
    icon: FileText,
    pricing: 'pay-per-use',
    price: 39.99,
    category: 'Cycle de location',
    badge: 'À la pièce',
    badgeDescription: 'Payez uniquement lors de la création d\'un bail'
  },
  {
    id: 'evenements',
    title: 'Événements',
    description: 'Participez à nos événements exclusifs',
    icon: Calendar,
    pricing: 'pay-per-use',
    price: 19.99,
    category: 'Espace membre',
    badge: 'À la pièce',
    badgeDescription: 'Payez uniquement lors de l\'inscription à un événement'
  },
  {
    id: 'formations',
    title: 'Formations',
    description: 'Développez vos compétences',
    icon: Users2,
    pricing: 'pay-per-use',
    price: 79.99,
    category: 'Espace membre',
    badge: 'À la pièce',
    badgeDescription: 'Payez uniquement lors de l\'inscription à une formation'
  },
  {
    id: 'recommandes',
    title: 'Recommandés électroniques',
    description: 'Envoyez des documents officiels',
    icon: Mail,
    pricing: 'pay-per-use',
    price: 14.99,
    category: 'Communication',
    badge: 'À la pièce',
    badgeDescription: 'Payez uniquement lors de l\'envoi d\'un recommandé'
  }
];

interface OnboardingTutorialProps {
  onComplete: () => void;
  userName: string;
}

const OnboardingTutorial: React.FC<OnboardingTutorialProps> = ({ onComplete, userName }) => {
  const [selectedService, setSelectedService] = useState<ServiceOption | null>(null);
  const [showSummary, setShowSummary] = useState(false);
  const [exploredServices, setExploredServices] = useState<string[]>([]);
  const [showVideo, setShowVideo] = useState(false);

  const handleServiceSelect = (service: ServiceOption) => {
    setSelectedService(service);
    setShowVideo(true);
    if (!exploredServices.includes(service.id)) {
      setExploredServices([...exploredServices, service.id]);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl max-w-4xl w-full mx-4 p-8 relative max-h-[90vh] overflow-y-auto">
        <button
          onClick={onComplete}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-500"
        >
          <X className="h-6 w-6" />
        </button>

        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">
            Bienvenue {userName} ! 👋
          </h2>
          <p className="text-lg text-gray-600 mb-2">
            Découvrons ensemble nos services
          </p>
          <p className="text-xl font-semibold text-indigo-600">
            Quel service souhaitez-vous explorer en priorité ?
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {serviceOptions.map((service) => (
            <button
              key={service.id}
              onClick={() => handleServiceSelect(service)}
              className={`
                p-4 rounded-xl border text-left transition-all duration-200
                ${selectedService?.id === service.id
                  ? 'border-indigo-500 bg-indigo-50 shadow-md transform scale-[1.02]'
                  : 'border-gray-200 hover:border-indigo-300 hover:bg-indigo-50 hover:scale-[1.02]'
                }
              `}
            >
              <div className="flex items-start space-x-3">
                <div className="p-2 bg-white rounded-lg">
                  <service.icon className="h-6 w-6 text-indigo-600" />
                </div>
                <div className="flex-1">
                  <h3 className="font-medium text-gray-900">{service.title}</h3>
                  <p className="text-sm text-gray-600 mt-1">{service.description}</p>
                  <div className="flex items-center justify-between mt-2">
                    <div className="group relative">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-50 text-blue-700 border border-blue-200">
                        {service.badge}
                        <HelpCircle className="ml-1 h-3 w-3" />
                      </span>
                      <div className="absolute bottom-full left-0 mb-2 w-48 p-2 bg-white rounded-lg shadow-lg border border-gray-100 invisible opacity-0 group-hover:visible group-hover:opacity-100 transition-all duration-200 z-50">
                        <p className="text-xs text-gray-600">{service.badgeDescription}</p>
                      </div>
                    </div>
                    <span className="text-sm font-medium text-indigo-600">
                      {service.price?.toFixed(2)}$
                    </span>
                  </div>
                </div>
              </div>
            </button>
          ))}
        </div>

        <div className="mt-8 flex justify-end">
          <button
            onClick={onComplete}
            className="px-6 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors flex items-center space-x-2"
          >
            <span>Accéder au tableau de bord</span>
            <ChevronRight className="h-5 w-5" />
          </button>
        </div>
      </div>

      {showVideo && selectedService && (
        <ServiceTutorialVideo
          service={selectedService}
          onClose={() => setShowVideo(false)}
        />
      )}
    </div>
  );
};

export default OnboardingTutorial;