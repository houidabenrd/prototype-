import React, { useState } from 'react';
import { ArrowLeft, Check, Star, Info, Shield, Calendar, FileText, Users, Mail, Building2, ArrowRight, ChevronRight, Bell, Settings, MessageCircle, CreditCard, Brain, FileBarChart } from 'lucide-react';
import ContactSalesPopup from './ContactSalesPopup';

interface PlanDetailsPageProps {
  plan: {
    name: string;
    price: number;
  };
  role: string;
  onBack: () => void;
  onSubscribe: () => void;
}

interface ModuleSection {
  title: string;
  icon: React.FC<{ className?: string }>;
  features: {
    name: string;
    included: boolean;
    payPerUse?: boolean;
    description?: string;
  }[];
}

const PlanDetailsPage: React.FC<PlanDetailsPageProps> = ({ plan, role, onBack, onSubscribe }) => {
  const [showContactSales, setShowContactSales] = useState(false);

  const modules: ModuleSection[] = [
    {
      title: "Fonctionnalités de base",
      icon: Bell,
      features: [
        { name: "Notifications", included: true, description: "Restez informé de toutes vos activités" },
        { name: "Paramètres du compte", included: true, description: "Gérez vos préférences et configurations" }
      ]
    },
    {
      title: "Cycle de location",
      icon: Building2,
      features: [
        { name: "Demande de location", included: true, description: "Gestion des demandes (validation d'identité en supplément)" },
        { name: "Reconduction de bail", included: true },
        { name: "Annonces", included: true, payPerUse: true, description: "Publication d'annonces avec rabais membre" },
        { name: "Enquêtes pré-location", included: true, payPerUse: true },
        { name: "Bail électronique", included: true, payPerUse: true }
      ]
    },
    {
      title: "Espace membre",
      icon: Users,
      features: [
        { name: "Répertoire des partenaires", included: true },
        { name: "Actualités", included: true },
        { name: "Événements", included: true, payPerUse: true },
        { name: "Formations", included: true, payPerUse: true },
        { name: "Service-conseil CORPIQ", included: true, payPerUse: true }
      ]
    },
    {
      title: "Gestion",
      icon: FileBarChart,
      features: [
        { name: "Gérer mon parc", included: true },
        { name: "Carnet d'adresses", included: true },
        { name: "Statistiques", included: true },
        { name: "Rapports", included: true },
        { name: "Travaux", included: true },
        { name: "Stockage et archives", included: true },
        { name: "Calculateur d'augmentation", included: true }
      ]
    },
    {
      title: "Communication",
      icon: MessageCircle,
      features: [
        { name: "Messagerie interne", included: true, description: "Avec copie par courriel" },
        { name: "Bibliothèque de modèles", included: true },
        { name: "Recommandé électronique", included: true, payPerUse: true },
        { name: "Messages textes", included: true, payPerUse: true }
      ]
    },
    {
      title: "Finance",
      icon: CreditCard,
      features: [
        { name: "Collecte de loyers", included: true },
        { name: "Gestion des dépenses", included: true },
        { name: "Relevé 31", included: true }
      ]
    },
    {
      title: "Automatisation",
      icon: Brain,
      features: [
        { name: "Règles d'affaires", included: true },
        { name: "Analyse IA du parc", included: true }
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header fixe */}
      <div className="sticky top-0 bg-white border-b border-gray-200 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="py-4 flex items-center justify-between">
            <button
              onClick={onBack}
              className="flex items-center text-gray-600 hover:text-gray-900"
            >
              <ArrowLeft className="h-5 w-5 mr-2" />
              Retour
            </button>
            <div className="flex items-center space-x-2">
              <Shield className="h-5 w-5 text-indigo-600" />
              <span className="text-sm font-medium text-gray-600">{role}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="bg-gradient-to-br from-indigo-600 to-indigo-800 rounded-2xl shadow-xl p-8 mb-8 text-white">
          <div className="max-w-4xl mx-auto">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between">
              <div className="mb-6 md:mb-0">
                <h1 className="text-4xl font-bold mb-4">
                  Forfait {plan.name}
                </h1>
                <div className="flex items-center space-x-2 text-indigo-100">
                  <Star className="h-5 w-5" />
                  <p className="text-lg">
                    Solution optimisée pour {role.toLowerCase()}
                  </p>
                </div>
              </div>
              <div className="text-center md:text-right">
                <div className="text-5xl font-bold">
                  {plan.price}$
                  <span className="text-xl font-normal text-indigo-200">/an</span>
                </div>
                <p className="text-indigo-200 mt-2">
                  Facturation annuelle
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Info Banner */}
        <div className="bg-indigo-50 rounded-xl p-6 border border-indigo-100 mb-8">
          <div className="flex items-start space-x-4">
            <div className="p-2 bg-indigo-100 rounded-lg flex-shrink-0">
              <Info className="h-5 w-5 text-indigo-600" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-indigo-900 mb-2">
                À propos de ce forfait
              </h3>
              <p className="text-indigo-700 text-sm leading-relaxed">
                Ce forfait vous donne accès à toutes les fonctionnalités de base et des tarifs préférentiels sur les services à la pièce.
                Les services payants à la pièce bénéficient automatiquement du rabais membre.
              </p>
            </div>
          </div>
        </div>

        {/* Modules Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {modules.map((module, index) => (
            <div
              key={index}
              className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden"
            >
              <div className="p-6">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="p-2 bg-indigo-50 rounded-lg">
                    <module.icon className="h-5 w-5 text-indigo-600" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900">
                    {module.title}
                  </h3>
                </div>
                <ul className="space-y-3">
                  {module.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start">
                      <div className="p-1 bg-green-100 rounded-full mr-3 flex-shrink-0 mt-1">
                        <Check className="h-3 w-3 text-green-600" />
                      </div>
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="text-sm text-gray-900">
                            {feature.name}
                          </span>
                          {feature.payPerUse && (
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 border border-blue-200">
                              Rabais membre
                            </span>
                          )}
                        </div>
                        {feature.description && (
                          <p className="text-xs text-gray-500 mt-0.5">
                            {feature.description}
                          </p>
                        )}
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>

        {/* CTA Section */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 mb-8">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Prêt à optimiser votre gestion immobilière ?
            </h2>
            <p className="text-gray-600 mb-6">
              Rejoignez les milliers de propriétaires qui font confiance à CORPIQ pour simplifier leur gestion locative.
            </p>
            <button
              onClick={onSubscribe}
              className="inline-flex items-center px-8 py-4 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-colors font-medium text-lg shadow-sm hover:shadow-md"
            >
              Souscrire au forfait {plan.name}
              <ArrowRight className="ml-2 h-5 w-5" />
            </button>
          </div>
        </div>

        {plan.name === 'Pro' && (
          <div className="bg-gradient-to-br from-gray-50 to-indigo-50 rounded-xl p-6 border border-indigo-100">
            <div className="flex items-start space-x-4">
              <div className="p-2 bg-indigo-100 rounded-lg">
                <Building2 className="h-5 w-5 text-indigo-600" />
              </div>
              <div>
                <h3 className="text-lg font-medium text-indigo-900">
                  Besoin d'une solution sur mesure ?
                </h3>
                <p className="mt-1 text-sm text-indigo-700">
                  Si le forfait Pro ne répond pas à tous vos besoins, nos chargés de compte sont là pour vous proposer une solution entreprise adaptée à votre situation.
                </p>
                <button
                  onClick={() => setShowContactSales(true)}
                  className="inline-flex items-center mt-4 text-sm font-medium text-indigo-600 hover:text-indigo-700"
                >
                  Contacter un chargé de compte
                  <ChevronRight className="ml-2 h-4 w-4" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Popup de prise de rendez-vous */}
        <ContactSalesPopup
          isOpen={showContactSales}
          onClose={() => setShowContactSales(false)}
        />
      </div>
    </div>
  );
};

export default PlanDetailsPage;