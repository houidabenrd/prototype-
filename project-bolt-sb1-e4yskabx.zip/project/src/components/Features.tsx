import React from 'react';
import { Search, FileBarChart, FileText, ScrollText, Mail, FileCheck, Users, Key, MessageSquare, Wallet, BarChart as ChartBar, GraduationCap, PieChart, BarChart2, HandshakeIcon, Users2, Settings, PenTool as Tool } from 'lucide-react';

const features = [
  {
    icon: Search,
    title: 'Enquêtes pré-location',
    description: 'Vérification approfondie des locataires potentiels'
  },
  {
    icon: FileBarChart,
    title: 'Rapports détaillés',
    description: 'Analyse complète de la performance de vos immeubles'
  },
  {
    icon: FileText,
    title: 'Baux électroniques',
    description: 'Création et gestion de baux conformes à la loi'
  },
  {
    icon: ScrollText,
    title: 'Modèles légaux',
    description: 'Documents juridiques prêts à l\'emploi'
  },
  {
    icon: Mail,
    title: 'Recommandés électroniques',
    description: 'Envoi sécurisé avec preuve de réception'
  },
  {
    icon: FileCheck,
    title: 'Gestion des annonces',
    description: 'Publication et suivi de vos offres de location'
  },
  {
    icon: Users,
    title: 'Gestion des demandes',
    description: 'Suivi centralisé des candidatures'
  },
  {
    icon: Wallet,
    title: 'Gestion financière',
    description: 'Suivi des revenus et dépenses'
  },
  {
    icon: ChartBar,
    title: 'Calculateur de rentabilité',
    description: 'Analyse de la performance financière'
  },
  {
    icon: PieChart,
    title: 'Analyse d\'investissement',
    description: 'Évaluation des opportunités immobilières'
  },
  {
    icon: BarChart2,
    title: 'Gestion de portefeuille',
    description: 'Vue d\'ensemble de vos investissements'
  },
  {
    icon: Users2,
    title: 'Multi-utilisateurs',
    description: 'Gestion des accès et permissions'
  }
];

const Features = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {features.map((feature, index) => (
        <div
          key={index}
          className="bg-white/80 backdrop-blur-sm p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow border border-gray-100"
        >
          <div className="flex items-start space-x-3">
            <div className="flex-shrink-0">
              <feature.icon className="w-6 h-6 text-indigo-600" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-gray-900">{feature.title}</h3>
              <p className="text-sm text-gray-600 mt-1">{feature.description}</p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default Features;