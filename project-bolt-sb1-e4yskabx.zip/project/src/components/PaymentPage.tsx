import React, { useState } from 'react';
import { ArrowLeft, CreditCard, Building2, Shield, Check, Calendar, Lock, TentIcon as PaymentIcon, Ban as Bank, Wallet, Info, ChevronRight, Star } from 'lucide-react';

interface PaymentPageProps {
  plan: {
    name: string;
    price: number;
  };
  role: string;
  onBack: () => void;
  onPaymentComplete: () => void;
}

const PaymentPage: React.FC<PaymentPageProps> = ({ plan, role, onBack, onPaymentComplete }) => {
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'bank' | 'wallet' | null>(null);
  const [cardNumber, setCardNumber] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [cvv, setCvv] = useState('');
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    setTimeout(() => {
      setLoading(false);
      onPaymentComplete();
    }, 2000);
  };

  const handlePayLater = () => {
    // Redirection vers le tableau de bord On Demand
    onPaymentComplete();
  };

  const paymentMethods = [
    {
      id: 'card',
      icon: CreditCard,
      title: 'Carte de crédit',
      description: 'Paiement sécurisé par carte',
      brands: ['Visa', 'Mastercard', 'American Express']
    },
    {
      id: 'bank',
      icon: Bank,
      title: 'Virement bancaire',
      description: 'Paiement direct depuis votre compte',
      brands: ['Desjardins', 'RBC', 'BMO', 'TD']
    },
    {
      id: 'wallet',
      icon: Wallet,
      title: 'Portefeuille numérique',
      description: 'PayPal, Apple Pay, Google Pay',
      brands: ['PayPal', 'Apple Pay', 'Google Pay']
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-indigo-50">
      {/* Header avec bouton retour */}
      <div className="sticky top-0 z-50 bg-white/80 backdrop-blur-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="py-4 flex items-center justify-between">
            <button
              onClick={onBack}
              className="group flex items-center text-gray-600 hover:text-gray-900 transition-colors"
            >
              <ArrowLeft className="h-5 w-5 mr-2 transform group-hover:-translate-x-1 transition-transform" />
              <span>Retour au forfait</span>
            </button>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Shield className="h-5 w-5 text-indigo-600" />
                <span className="text-sm font-medium text-gray-600">{role}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Résumé de la commande */}
        <div className="bg-gradient-to-br from-indigo-600 to-indigo-800 rounded-xl shadow-lg p-8 mb-8 text-white relative overflow-hidden">
          <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1557683316-973673baf926?auto=format&fit=crop&q=80')] opacity-10 mix-blend-overlay" />
          <div className="relative">
            <h2 className="text-2xl font-bold mb-6">Résumé de votre commande</h2>
            <div className="flex items-start justify-between pb-6 border-b border-white/20">
              <div>
                <h3 className="text-xl font-medium">Forfait {plan.name}</h3>
                <p className="text-indigo-200 mt-1">Abonnement annuel</p>
                <div className="flex items-center mt-4 space-x-4">
                  <div className="flex items-center">
                    <Star className="h-5 w-5 text-yellow-400 mr-2" />
                    <span className="text-sm">Support prioritaire</span>
                  </div>
                  <div className="flex items-center">
                    <Check className="h-5 w-5 text-green-400 mr-2" />
                    <span className="text-sm">Sans engagement</span>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-3xl font-bold">{plan.price}$</div>
                <p className="text-indigo-200 text-sm mt-1">TVQ et TPS incluses</p>
              </div>
            </div>
            <div className="mt-6 flex items-center justify-between text-sm">
              <span className="text-indigo-200">Total à payer aujourd'hui</span>
              <span className="text-2xl font-bold">{plan.price}$</span>
            </div>
          </div>
        </div>

        {/* Boutons d'action */}
        <div className="flex justify-between items-center mb-8">
          <button
            onClick={handlePayLater}
            className="px-6 py-3 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors font-medium"
          >
            Payer plus tard
          </button>
          <button
            onClick={() => setPaymentMethod('card')}
            className="px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors font-medium"
          >
            Payer maintenant
          </button>
        </div>

        {/* Méthodes de paiement */}
        {paymentMethod && (
          <div className="space-y-8">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold text-gray-900">Choisissez votre méthode de paiement</h2>
              <div className="flex items-center">
                <Lock className="h-5 w-5 text-green-500 mr-2" />
                <span className="text-sm text-gray-600">Paiement sécurisé</span>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {paymentMethods.map((method) => (
                <button
                  key={method.id}
                  onClick={() => setPaymentMethod(method.id as typeof paymentMethod)}
                  className={`
                    relative p-6 rounded-xl border-2 text-left transition-all duration-300
                    ${paymentMethod === method.id
                      ? 'border-indigo-600 bg-indigo-50 shadow-md transform scale-[1.02]'
                      : 'border-gray-200 hover:border-indigo-200 hover:bg-gray-50'
                    }
                  `}
                >
                  <div className="flex items-start space-x-4">
                    <div className={`
                      p-3 rounded-xl
                      ${paymentMethod === method.id ? 'bg-indigo-100' : 'bg-gray-100'}
                      transition-colors duration-300
                    `}>
                      <method.icon className={`
                        h-6 w-6
                        ${paymentMethod === method.id ? 'text-indigo-600' : 'text-gray-600'}
                        transition-colors duration-300
                      `} />
                    </div>
                    <div>
                      <div className="font-medium text-gray-900">{method.title}</div>
                      <div className="text-sm text-gray-500 mt-1">{method.description}</div>
                      <div className="flex flex-wrap gap-2 mt-3">
                        {method.brands.map((brand) => (
                          <span
                            key={brand}
                            className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800"
                          >
                            {brand}
                          </span>
                        ))}
                      </div>
                    </div>
                    <div className={`
                      absolute top-4 right-4 w-4 h-4 rounded-full border-2
                      ${paymentMethod === method.id
                        ? 'border-indigo-600 bg-indigo-600'
                        : 'border-gray-300'
                      }
                      transition-colors duration-300
                    `}>
                      {paymentMethod === method.id && (
                        <div className="absolute inset-0 flex items-center justify-center">
                          <div className="w-2 h-2 rounded-full bg-white" />
                        </div>
                      )}
                    </div>
                  </div>
                </button>
              ))}
            </div>

            {/* Formulaire de carte de crédit */}
            {paymentMethod === 'card' && (
              <div className="bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden">
                <div className="p-6 bg-gradient-to-br from-gray-50 to-white border-b border-gray-200">
                  <h3 className="text-lg font-semibold text-gray-900">Informations de paiement</h3>
                  <p className="text-sm text-gray-500 mt-1">
                    Entrez les détails de votre carte de crédit
                  </p>
                </div>
                
                <form onSubmit={handleSubmit} className="p-6 space-y-6">
                  <div className="space-y-4">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                        Nom sur la carte
                      </label>
                      <input
                        type="text"
                        id="name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:ring-indigo-500 focus:border-indigo-500 transition-colors"
                        placeholder="John Doe"
                        required
                      />
                    </div>

                    <div>
                      <label htmlFor="cardNumber" className="block text-sm font-medium text-gray-700">
                        Numéro de carte
                      </label>
                      <div className="mt-1 relative rounded-md shadow-sm">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                          <CreditCard className="h-5 w-5 text-gray-400" />
                        </div>
                        <input
                          type="text"
                          id="cardNumber"
                          value={cardNumber}
                          onChange={(e) => setCardNumber(e.target.value)}
                          className="block w-full pl-10 rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 transition-colors"
                          placeholder="4242 4242 4242 4242"
                          required
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="expiry" className="block text-sm font-medium text-gray-700">
                          Date d'expiration
                        </label>
                        <div className="mt-1 relative rounded-md shadow-sm">
                          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <Calendar className="h-5 w-5 text-gray-400" />
                          </div>
                          <input
                            type="text"
                            id="expiry"
                            value={expiryDate}
                            onChange={(e) => setExpiryDate(e.target.value)}
                            className="block w-full pl-10 rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 transition-colors"
                            placeholder="MM/AA"
                            required
                          />
                        </div>
                      </div>

                      <div>
                        <label htmlFor="cvv" className="block text-sm font-medium text-gray-700">
                          Code de sécurité
                        </label>
                        <div className="mt-1 relative rounded-md shadow-sm">
                          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <Lock className="h-5 w-5 text-gray-400" />
                          </div>
                          <input
                            type="text"
                            id="cvv"
                            value={cvv}
                            onChange={(e) => setCvv(e.target.value)}
                            className="block w-full pl-10 rounded-lg border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 transition-colors"
                            placeholder="123"
                            required
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="pt-6 border-t border-gray-200">
                    <button
                      type="submit"
                      disabled={loading}
                      className={`
                        w-full flex items-center justify-center px-6 py-3 rounded-lg text-white text-lg font-medium
                        ${loading
                          ? 'bg-gray-400 cursor-not-allowed'
                          : 'bg-indigo-600 hover:bg-indigo-700'
                        }
                        transition-all duration-300 transform hover:scale-[1.02]
                      `}
                    >
                      {loading ? (
                        <>
                          <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                          </svg>
                          Traitement en cours...
                        </>
                      ) : (
                        <>
                          Payer {plan.price}$
                          <ChevronRight className="ml-2 h-5 w-5" />
                        </>
                      )}
                    </button>
                  </div>
                </form>
              </div>
            )}

            {/* Message pour les autres méthodes de paiement */}
            {(paymentMethod === 'bank' || paymentMethod === 'wallet') && (
              <div className="bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden">
                <div className="p-6 bg-gradient-to-br from-gray-50 to-white border-b border-gray-200">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-indigo-100 rounded-lg">
                      {paymentMethod === 'bank' ? (
                        <Bank className="h-5 w-5 text-indigo-600" />
                      ) : (
                        <Wallet className="h-5 w-5 text-indigo-600" />
                      )}
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900">
                      {paymentMethod === 'bank' ? 'Virement bancaire' : 'Portefeuille numérique'}
                    </h3>
                  </div>
                </div>
                
                <div className="p-6">
                  <p className="text-gray-600">
                    {paymentMethod === 'bank'
                      ? 'Vous serez redirigé vers votre banque pour effectuer le paiement en toute sécurité.'
                      : 'Vous serez redirigé vers la plateforme de paiement de votre choix.'}
                  </p>
                  <button
                    onClick={handleSubmit}
                    disabled={loading}
                    className={`
                      mt-6 w-full flex items-center justify-center px-6 py-3 rounded-lg text-white text-lg font-medium
                      ${loading
                        ? 'bg-gray-400 cursor-not-allowed'
                        : 'bg-indigo-600 hover:bg-indigo-700'
                      }
                      transition-all duration-300 transform hover:scale-[1.02]
                    `}
                  >
                    {loading ? (
                      <>
                        <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Redirection en cours...
                      </>
                    ) : (
                      <>
                        Continuer vers le paiement
                        <ChevronRight className="ml-2 h-5 w-5" />
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}

            {/* Informations de sécurité */}
            <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl p-6 border border-green-100">
              <div className="flex items-start space-x-4">
                <div className="p-2 bg-green-100 rounded-lg">
                  <Lock className="h-6 w-6 text-green-600" />
                </div>
                <div>
                  <h3 className="font-medium text-green-900">Paiement 100% sécurisé</h3>
                  <p className="mt-1 text-sm text-green-700">
                    Toutes vos informations sont cryptées avec SSL. Nous ne stockons jamais vos données de paiement.
                  </p>
                  <div className="mt-4 flex items-center space-x-6">
                    <div className="flex items-center">
                      <Shield className="h-5 w-5 text-green-600 mr-2" />
                      <span className="text-sm text-green-700">Protection SSL</span>
                    </div>
                    <div className="flex items-center">
                      <Check className="h-5 w-5 text-green-600 mr-2" />
                      <span className="text-sm text-green-700">Transactions sécurisées</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PaymentPage;