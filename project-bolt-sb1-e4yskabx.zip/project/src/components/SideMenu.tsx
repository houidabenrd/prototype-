import React from 'react';
import { Newspaper, Calendar, GraduationCap, Info, ChevronRight } from 'lucide-react';

interface SideMenuProps {
  onServiceSelect: (serviceId: string) => void;
  activeService?: string;
}

const services = [
  {
    id: 'actualites',
    title: 'Actualité',
    description: '3 articles inclus',
    icon: Newspaper,
    type: 'limited',
    badge: 'Accès limité'
  },
  {
    id: 'evenements',
    title: 'Événements',
    description: '19.99$ / unité',
    icon: Calendar,
    type: 'pay-per-use',
    badge: 'Paiement à la pièce'
  },
  {
    id: 'formations',
    title: 'Formations',
    description: '79.99$ / unité',
    icon: GraduationCap,
    type: 'pay-per-use',
    badge: 'Paiement à la pièce'
  }
];

const SideMenu: React.FC<SideMenuProps> = ({ onServiceSelect, activeService }) => {
  return (
    <div className="w-72 bg-white border-r border-gray-200 h-full overflow-y-auto">
      <div className="p-4">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">
          Espace Membre
        </h2>
        <div className="space-y-2">
          {services.map((service) => (
            <button
              key={service.id}
              onClick={() => onServiceSelect(service.id)}
              className={`
                w-full text-left p-3 rounded-lg transition-all duration-200
                ${activeService === service.id 
                  ? 'bg-indigo-50 border-l-4 border-indigo-500' 
                  : 'hover:bg-gray-50 border-l-4 border-transparent'
                }
              `}
            >
              <div className="flex items-start space-x-3">
                <div className={`
                  p-2 rounded-lg
                  ${service.type === 'limited' ? 'bg-yellow-50' : 'bg-blue-50'}
                `}>
                  <service.icon className={`
                    h-5 w-5
                    ${service.type === 'limited' ? 'text-yellow-600' : 'text-blue-600'}
                  `} />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h3 className="font-medium text-gray-900">
                      {service.title}
                    </h3>
                    <ChevronRight className={`
                      h-4 w-4 transition-transform
                      ${activeService === service.id ? 'rotate-90' : ''}
                    `} />
                  </div>
                  <div className="flex items-center mt-1 space-x-2">
                    <span className={`
                      inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium
                      ${service.type === 'limited' 
                        ? 'bg-yellow-50 text-yellow-700 border border-yellow-200' 
                        : 'bg-blue-50 text-blue-700 border border-blue-200'
                      }
                    `}>
                      {service.badge}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600 mt-1">
                    {service.description}
                  </p>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Bannière promotionnelle */}
      <div className="p-4 mt-4">
        <div className="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-lg p-4 text-white">
          <div className="flex items-start space-x-3">
            <Info className="h-5 w-5 flex-shrink-0" />
            <div>
              <h4 className="font-medium mb-1">Passez au forfait Starter</h4>
              <p className="text-sm text-indigo-100">
                Accès illimité à tous les services de l'Espace Membre
              </p>
              <button className="mt-3 px-3 py-1.5 bg-white text-indigo-600 rounded-lg text-sm font-medium hover:bg-indigo-50 transition-colors">
                En savoir plus
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SideMenu;