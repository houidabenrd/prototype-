import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, Grid, List, Search, Star, MessageCircle, Volume, 
  Sparkles, Filter, ChevronDown, X, BookOpen, ArrowRight,
  Clock, AlertCircle, Bookmark, Share2, ThumbsUp, Eye
} from 'lucide-react';

interface Article {
  id: string;
  title: string;
  content: string;
  summary?: string;
  date: string;
  category: string;
  image: string;
  isLocked?: boolean;
  readTime?: number;
  views?: number;
  likes?: number;
  aiScore?: number;
  tags?: string[];
}

interface NewsPageProps {
  onBack: () => void;
}

const articles: Article[] = [
  {
    id: '1',
    title: 'Les nouvelles tendances du marché locatif en 2024',
    content: 'Analyse approfondie des tendances actuelles du marché locatif...',
    summary: 'Le marché locatif connaît une transformation majeure en 2024, avec une augmentation de la demande dans les zones périurbaines et une évolution des critères des locataires.',
    date: '2024-02-15',
    category: 'Marché',
    image: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80',
    readTime: 5,
    views: 1250,
    likes: 45,
    aiScore: 0.89,
    tags: ['Tendances', 'Analyse', 'Marché locatif']
  },
  {
    id: '2',
    title: 'Guide complet : Optimisation fiscale pour propriétaires',
    content: 'Découvrez les meilleures stratégies pour optimiser votre fiscalité...',
    summary: 'Un guide détaillé sur les stratégies d\'optimisation fiscale spécifiques aux propriétaires immobiliers, incluant les dernières modifications législatives.',
    date: '2024-02-14',
    category: 'Fiscalité',
    image: 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80',
    isLocked: true,
    readTime: 8,
    views: 2100,
    likes: 78,
    aiScore: 0.95,
    tags: ['Fiscalité', 'Guide', 'Optimisation']
  },
  {
    id: '3',
    title: 'Nouvelles réglementations : Ce qui change en 2024',
    content: 'Mise à jour sur les changements réglementaires importants...',
    summary: 'Panorama complet des nouvelles réglementations affectant les propriétaires et gestionnaires immobiliers en 2024.',
    date: '2024-02-13',
    category: 'Juridique',
    image: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&q=80',
    readTime: 6,
    views: 1800,
    likes: 62,
    aiScore: 0.92,
    tags: ['Réglementation', 'Juridique', 'Mise à jour']
  }
];

const NewsPage: React.FC<NewsPageProps> = ({ onBack }) => {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [showChatbot, setShowChatbot] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [showAIRecommendations, setShowAIRecommendations] = useState(true);
  const [chatMessages, setChatMessages] = useState<Array<{type: 'user' | 'assistant', content: string}>>([]);
  const [userInput, setUserInput] = useState('');

  const categories = ['Tous', 'Marché', 'Juridique', 'Fiscalité', 'Gestion'];

  const filteredArticles = articles.filter(article => {
    if (selectedCategory && selectedCategory !== 'Tous' && article.category !== selectedCategory) {
      return false;
    }
    if (searchQuery) {
      const searchLower = searchQuery.toLowerCase();
      return article.title.toLowerCase().includes(searchLower) ||
             article.content.toLowerCase().includes(searchLower) ||
             article.tags?.some(tag => tag.toLowerCase().includes(searchLower));
    }
    return true;
  });

  const aiRecommendations = [
    {
      title: "Articles recommandés pour vous",
      articles: filteredArticles
        .sort((a, b) => (b.aiScore || 0) - (a.aiScore || 0))
        .slice(0, 3)
    }
  ];

  const handleChatSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userInput.trim()) return;

    setChatMessages(prev => [...prev, { type: 'user', content: userInput }]);

    setTimeout(() => {
      const aiResponse = {
        type: 'assistant' as const,
        content: `Je peux vous aider à trouver des articles pertinents sur "${userInput}". Voici quelques suggestions basées sur vos intérêts.`
      };
      setChatMessages(prev => [...prev, aiResponse]);
    }, 1000);

    setUserInput('');
  };

  const renderArticleCard = (article: Article, index: number) => (
    <div key={article.id} className="bg-white rounded-xl shadow-sm hover:shadow-md transition-all duration-300 overflow-hidden border border-gray-100">
      <div className="relative h-48">
        <img
          src={article.image}
          alt={article.title}
          className="w-full h-full object-cover"
        />
        {article.isLocked && (
          <div className="absolute top-4 right-4">
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-orange-100 text-orange-800">
              <Star className="h-4 w-4 mr-1" />
              Premium
            </span>
          </div>
        )}
        {article.aiScore && article.aiScore > 0.8 && (
          <div className="absolute top-4 left-4">
            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
              <Sparkles className="h-4 w-4 mr-1" />
              Recommandé pour vous
            </span>
          </div>
        )}
      </div>
      <div className="p-6">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-gray-500">
            {new Date(article.date).toLocaleDateString('fr-FR')}
          </span>
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800">
            {article.category}
          </span>
        </div>
        <h3 className="text-lg font-semibold text-gray-900 mb-2">
          {article.title}
        </h3>
        <p className="text-gray-600 text-sm mb-4">
          {article.summary || article.content}
        </p>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-4 text-sm text-gray-500">
            <span className="flex items-center">
              <Clock className="h-4 w-4 mr-1" />
              {article.readTime} min
            </span>
            <span className="flex items-center">
              <Eye className="h-4 w-4 mr-1" />
              {article.views}
            </span>
            <span className="flex items-center">
              <ThumbsUp className="h-4 w-4 mr-1" />
              {article.likes}
            </span>
          </div>
          <div className="flex items-center space-x-2">
            <button className="p-1 hover:bg-gray-100 rounded-full">
              <Bookmark className="h-4 w-4 text-gray-400" />
            </button>
            <button className="p-1 hover:bg-gray-100 rounded-full">
              <Share2 className="h-4 w-4 text-gray-400" />
            </button>
          </div>
        </div>
        <div className="flex items-center justify-between">
          <div className="flex flex-wrap gap-2">
            {article.tags?.map((tag, tagIndex) => (
              <span key={`${article.id}-tag-${tagIndex}`} className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded-full">
                {tag}
              </span>
            ))}
          </div>
          <button className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors text-sm">
            {article.isLocked ? 'Débloquer' : 'Lire'}
          </button>
        </div>
      </div>
    </div>
  );

  const renderChatbot = () => (
    <div className="fixed bottom-4 right-4 w-96 bg-white rounded-xl shadow-lg border border-gray-200">
      <div className="p-4 border-b border-gray-200 flex justify-between items-center bg-indigo-600 text-white rounded-t-xl">
        <div className="flex items-center space-x-2">
          <MessageCircle className="h-5 w-5" />
          <h3 className="font-semibold">Assistant IA</h3>
        </div>
        <button
          onClick={() => setShowChatbot(false)}
          className="text-white hover:text-gray-200"
        >
          <X className="h-5 w-5" />
        </button>
      </div>
      <div className="h-96 flex flex-col">
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {chatMessages.map((message, index) => (
            <div
              key={`chat-message-${index}`}
              className={`flex ${
                message.type === 'user' ? 'justify-end' : 'justify-start'
              }`}
            >
              <div
                className={`max-w-[80%] rounded-lg p-3 ${
                  message.type === 'user'
                    ? 'bg-indigo-600 text-white'
                    : 'bg-gray-100 text-gray-900'
                }`}
              >
                {message.content}
              </div>
            </div>
          ))}
        </div>
        <form onSubmit={handleChatSubmit} className="p-4 border-t border-gray-200">
          <div className="flex space-x-2">
            <input
              type="text"
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              placeholder="Posez votre question..."
              className="flex-1 px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            />
            <button
              type="submit"
              className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
            >
              Envoyer
            </button>
          </div>
        </form>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <button
            onClick={onBack}
            className="flex items-center text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="h-5 w-5 mr-2" />
            Retour au tableau de bord
          </button>
          <div className="flex items-center space-x-4">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 rounded-lg ${
                viewMode === 'grid' ? 'bg-indigo-100 text-indigo-600' : 'text-gray-400 hover:text-gray-500'
              }`}
            >
              <Grid className="h-5 w-5" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 rounded-lg ${
                viewMode === 'list' ? 'bg-indigo-100 text-indigo-600' : 'text-gray-400 hover:text-gray-500'
              }`}
            >
              <List className="h-5 w-5" />
            </button>
          </div>
        </div>

        <div className="mb-8 space-y-4">
          <div className="flex items-center space-x-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Rechercher dans les actualités..."
                className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>
            <button
              onClick={() => setShowChatbot(true)}
              className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors flex items-center"
            >
              <MessageCircle className="h-5 w-5 mr-2" />
              Assistant IA
            </button>
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className={`p-2 rounded-lg ${
                isPlaying ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-600'
              }`}
            >
              <Volume className="h-5 w-5" />
            </button>
          </div>

          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Filter className="h-5 w-5 text-gray-400" />
              <span className="text-sm text-gray-600">Filtrer par :</span>
            </div>
            {categories.map((category, index) => (
              <button
                key={`category-${index}`}
                onClick={() => setSelectedCategory(category === 'Tous' ? null : category)}
                className={`px-3 py-1 rounded-lg text-sm ${
                  (selectedCategory === category) || (!selectedCategory && category === 'Tous')
                    ? 'bg-indigo-100 text-indigo-600'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>

        {showAIRecommendations && (
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <Sparkles className="h-5 w-5 text-indigo-600" />
                <h2 className="text-lg font-semibold text-gray-900">
                  Recommandé pour vous
                </h2>
              </div>
              <button
                onClick={() => setShowAIRecommendations(false)}
                className="text-sm text-gray-500 hover:text-gray-700"
              >
                Masquer
              </button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {aiRecommendations[0].articles.map((article, index) => (
                <div key={`recommendation-${article.id}`} className="relative">
                  {renderArticleCard(article, index)}
                  {article.aiScore && (
                    <div className="absolute -top-2 -right-2 bg-indigo-600 text-white text-xs rounded-full px-2 py-1">
                      {(article.aiScore * 100).toFixed(0)}% pertinent
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        <div className={
          viewMode === 'grid'
            ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6'
            : 'space-y-6'
        }>
          {filteredArticles.map((article, index) => renderArticleCard(article, index))}
        </div>

        <div className="mt-8 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-xl p-6 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="p-3 bg-white/10 rounded-xl">
                <Star className="h-6 w-6 text-white" />
              </div>
              <div>
                <h3 className="text-lg font-semibold">Passez au forfait Starter</h3>
                <p className="mt-1 text-indigo-100">
                  Accédez à tous les articles premium et économisez jusqu'à 50%
                </p>
              </div>
            </div>
            <button className="px-6 py-3 bg-white text-indigo-600 rounded-lg font-medium hover:bg-indigo-50 transition-colors flex items-center">
              Découvrir l'offre
              <ArrowRight className="ml-2 h-5 w-5" />
            </button>
          </div>
        </div>
      </div>

      {showChatbot && renderChatbot()}
    </div>
  );
};

export default NewsPage;