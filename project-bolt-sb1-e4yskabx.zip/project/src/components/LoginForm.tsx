import React, { useState } from 'react';
import { Mail, Lock, ArrowRight, Linkedin, AppWindow as WindowsLogo, Facebook } from 'lucide-react';

interface LoginFormProps {
  onLoginSuccess: () => void;
  onRegisterClick: () => void;
  isMemberVerified: boolean;
}

const LoginForm: React.FC<LoginFormProps> = ({ onLoginSuccess, onRegisterClick, isMemberVerified }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState({
    email: '',
    password: ''
  });

  const handleSocialLogin = (provider: string) => {
    console.log(`Connexion avec ${provider}`);
    // Ici, vous implémenteriez la logique de connexion sociale
    onLoginSuccess();
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Connexion avec:', { email, password });
    onLoginSuccess();
  };

  return (
    <div className="bg-white/80 backdrop-blur-lg rounded-xl shadow-lg p-8 border border-gray-100">
      <h2 className="text-2xl font-semibold text-gray-900 mb-6 text-center">
        Connexion
      </h2>

      <div className="space-y-4 mb-6">
        <button
          onClick={() => handleSocialLogin('Microsoft')}
          className="w-full flex items-center justify-center px-6 py-3 bg-gray-800 text-white rounded-lg hover:bg-gray-900 transition-colors"
        >
          <WindowsLogo className="h-5 w-5 mr-3" />
          Continuer avec Microsoft
        </button>

        <button
          onClick={() => handleSocialLogin('LinkedIn')}
          className="w-full flex items-center justify-center px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Linkedin className="h-5 w-5 mr-3" />
          Continuer avec LinkedIn
        </button>

        <button
          onClick={() => handleSocialLogin('Facebook')}
          className="w-full flex items-center justify-center px-6 py-3 bg-blue-700 text-white rounded-lg hover:bg-blue-800 transition-colors"
        >
          <Facebook className="h-5 w-5 mr-3" />
          Continuer avec Facebook
        </button>
      </div>

      <div className="relative mb-6">
        <div className="absolute inset-0 flex items-center">
          <div className="w-full border-t border-gray-300"></div>
        </div>
        <div className="relative flex justify-center text-sm">
          <span className="px-2 bg-white text-gray-500">Ou</span>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="email" className="block text-sm font-medium text-gray-700">
            Adresse email
          </label>
          <div className="mt-1 relative rounded-md shadow-sm">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Mail className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="email"
              id="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
              placeholder="vous@exemple.com"
            />
          </div>
          {errors.email && (
            <p className="mt-1 text-sm text-red-600">{errors.email}</p>
          )}
        </div>

        <div>
          <label htmlFor="password" className="block text-sm font-medium text-gray-700">
            Mot de passe
          </label>
          <div className="mt-1 relative rounded-md shadow-sm">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Lock className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="password"
              id="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
              placeholder="••••••••"
            />
          </div>
          {errors.password && (
            <p className="mt-1 text-sm text-red-600">{errors.password}</p>
          )}
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <input
              id="remember-me"
              name="remember-me"
              type="checkbox"
              className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
            />
            <label htmlFor="remember-me" className="ml-2 block text-sm text-gray-900">
              Se souvenir de moi
            </label>
          </div>

          <div className="text-sm">
            <a href="#" className="font-medium text-indigo-600 hover:text-indigo-500">
              Mot de passe oublié ?
            </a>
          </div>
        </div>

        <div>
          <button
            type="submit"
            className="w-full flex justify-center items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            Se connecter
            <ArrowRight className="ml-2 h-4 w-4" />
          </button>
        </div>
      </form>

      <div className="text-center mt-6">
        <button
          type="button"
          onClick={onRegisterClick}
          className="text-sm text-indigo-600 hover:text-indigo-500"
        >
          Nouveau membre ? Créer un compte
        </button>
      </div>
    </div>
  );
};

export default LoginForm;