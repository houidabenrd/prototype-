import React, { useState } from 'react';
import { Building2, Users2, BarChart, FileText, PenTool as Tool, Archive, Calculator, Info, Lock, ArrowRight, Sparkles } from 'lucide-react';
import StarterFeaturePopup from './StarterFeaturePopup';

const managementFeatures = [
  {
    id: 'parc',
    icon: Building2,
    title: 'Gérer mon parc',
    description: 'Gestion centralisée de vos propriétés',
    features: [
      'Vue d\'ensemble du parc',
      'Suivi des occupations',
      'Gestion des documents',
      'Historique des interventions'
    ],
    available: false
  },
  {
    id: 'contacts',
    icon: Users2,
    title: 'Carnet d\'adresses',
    description: 'Gestion des contacts et partenaires',
    features: [
      'Répertoire centralisé',
      'Catégorisation des contacts',
      'Notes et historique',
      'Partage d\'informations'
    ],
    available: false
  },
  {
    id: 'stats',
    icon: BarChart,
    title: 'Statistiques',
    description: 'Analyses et tableaux de bord',
    features: [
      'Indicateurs clés',
      'Graphiques interactifs',
      'Rapports personnalisés',
      'Export des données'
    ],
    available: false
  },
  {
    id: 'reports',
    icon: FileText,
    title: 'Rapports',
    description: 'Génération de rapports détaillés',
    features: [
      'Modèles personnalisables',
      'Export multi-formats',
      'Rapports automatiques',
      'Archivage intelligent'
    ],
    available: false
  },
  {
    id: 'maintenance',
    icon: Tool,
    title: 'Travaux',
    description: 'Suivi des travaux et maintenance',
    features: [
      'Planification des travaux',
      'Suivi des interventions',
      'Gestion des devis',
      'Photos et documents'
    ],
    available: false
  },
  {
    id: 'storage',
    icon: Archive,
    title: 'Stockage et archives',
    description: 'Gestion documentaire sécurisée',
    features: [
      'Stockage illimité',
      'Classement intelligent',
      'Recherche avancée',
      'Partage sécurisé'
    ],
    available: false
  },
  {
    id: 'calculator',
    icon: Calculator,
    title: 'Calculateur d\'augmentation',
    description: 'Calcul des augmentations de loyer',
    features: [
      'Calcul automatique',
      'Historique des calculs',
      'Modèles d\'avis',
      'Export PDF'
    ],
    available: false
  }
];

const Management = () => {
  const [showFeaturePopup, setShowFeaturePopup] = useState(false);
  const [selectedFeature, setSelectedFeature] = useState<typeof managementFeatures[0] | null>(null);

  const handleFeatureClick = (feature: typeof managementFeatures[0]) => {
    if (!feature.available) {
      setSelectedFeature(feature);
      setShowFeaturePopup(true);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Gestion</h2>
          <p className="mt-1 text-gray-600">Outils de gestion immobilière avancés</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {managementFeatures.map((feature) => (
          <div
            key={feature.id}
            onClick={() => handleFeatureClick(feature)}
            className={`
              bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden
              ${!feature.available ? 'feature-locked cursor-pointer' : ''}
              transition-all duration-300 hover:scale-[1.02] hover:shadow-md
              group relative
            `}
          >
            {/* VIP Badge */}
            {!feature.available && (
              <div className="absolute top-3 right-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white text-xs px-2 py-1 rounded-full transform rotate-3 opacity-0 group-hover:opacity-100 transition-opacity z-10 flex items-center">
                <Sparkles className="h-3 w-3 mr-1" />
                Starter
              </div>
            )}

            <div className="p-6">
              <div className="flex items-start space-x-4">
                <div className={`p-3 rounded-xl ${feature.available ? 'bg-indigo-50' : 'bg-gray-50 group-hover:bg-indigo-50 transition-colors'}`}>
                  <feature.icon className={`h-6 w-6 ${feature.available ? 'text-indigo-600' : 'text-gray-400 group-hover:text-indigo-600 transition-colors'}`} />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-semibold text-gray-900">{feature.title}</h3>
                    {!feature.available && (
                      <Lock className="h-5 w-5 text-gray-400 group-hover:text-indigo-600 transition-colors" />
                    )}
                  </div>
                  <p className="mt-1 text-sm text-gray-600">{feature.description}</p>
                </div>
              </div>

              <div className="mt-6 space-y-3">
                {feature.features.map((featureItem, index) => (
                  <div key={index} className="flex items-center text-sm text-gray-600">
                    <div className="w-1.5 h-1.5 rounded-full bg-gray-300 mr-2"></div>
                    {featureItem}
                  </div>
                ))}
              </div>

              {!feature.available && (
                <div className="mt-6 p-3 bg-gray-50 rounded-lg border border-gray-200 group-hover:bg-indigo-50 group-hover:border-indigo-100 transition-colors">
                  <div className="flex items-center text-sm text-gray-600 group-hover:text-indigo-600">
                    <Info className="h-4 w-4 mr-2" />
                    <span>Débloquez cette fonctionnalité avec le forfait Starter</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Promo Banner */}
      <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div className="flex items-start space-x-4">
            <div className="p-3 bg-white/10 rounded-xl">
              <Lock className="h-6 w-6 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-semibold">Accédez à tous les outils de gestion</h3>
              <p className="mt-1 text-indigo-100">
                Le forfait Starter vous donne accès à toutes les fonctionnalités de gestion pour seulement 199$/an
              </p>
            </div>
          </div>
          <button className="px-6 py-3 bg-white text-indigo-600 rounded-lg font-medium hover:bg-indigo-50 transition-colors flex items-center">
            Passer au forfait Starter
            <ArrowRight className="ml-2 h-5 w-5" />
          </button>
        </div>
      </div>

      {/* Starter Feature Popup */}
      {selectedFeature && (
        <StarterFeaturePopup
          isOpen={showFeaturePopup}
          onClose={() => setShowFeaturePopup(false)}
          feature={{
            title: selectedFeature.title,
            description: selectedFeature.description
          }}
        />
      )}
    </div>
  );
};

export default Management;