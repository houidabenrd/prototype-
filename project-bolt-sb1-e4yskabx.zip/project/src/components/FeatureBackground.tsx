import React, { useState } from 'react';
import { Building2, Bell, FileText, BarChart as ChartBar, GraduationCap, BarChart2, ScrollText, Users, Mail, MessageSquare, ClipboardCheck, Calculator, Calendar, FileBarChart, HandshakeIcon, Shield, PenTool as Tool, DollarSign, FileSearch, Scale } from 'lucide-react';

interface Feature {
  icon: React.FC<{ className?: string }>;
  title: string;
  description: string;
  position: string;
  delay: number;
}

const features: Feature[] = [
  // Fonctionnalités en haut
  {
    icon: Building2,
    title: 'Gestion locative',
    description: 'Gérez efficacement vos propriétés et locataires',
    position: 'top-8 right-[30%]',
    delay: 0.2
  },
  {
    icon: Calendar,
    title: 'Calendrier',
    description: 'Planifiez et suivez vos échéances',
    position: 'top-8 left-[30%]',
    delay: 0.4
  },
  // Notifications à gauche (symétrique avec les baux électroniques)
  {
    icon: Bell,
    title: 'Notifications',
    description: 'Restez informé des événements importants',
    position: 'top-[20%] left-12',
    delay: 0
  },
  // Baux électroniques à droite
  {
    icon: FileText,
    title: 'Baux électroniques',
    description: 'Créez et gérez vos baux en ligne',
    position: 'top-[20%] right-12',
    delay: 1.0
  },
  // Autres fonctionnalités à gauche
  {
    icon: FileSearch,
    title: 'Enquêtes pré-location',
    description: 'Vérifiez les antécédents des locataires',
    position: 'top-[35%] left-20',
    delay: 0.6
  },
  {
    icon: Scale,
    title: 'Service juridique',
    description: 'Conseils et assistance juridique',
    position: 'bottom-[35%] left-12',
    delay: 0.8
  },
  // Autres fonctionnalités à droite
  {
    icon: HandshakeIcon,
    title: 'Partenaires',
    description: 'Accédez au réseau de professionnels',
    position: 'top-[35%] right-20',
    delay: 1.2
  },
  {
    icon: Tool,
    title: 'Maintenance',
    description: 'Gérez les demandes et suivis des travaux',
    position: 'bottom-[35%] right-12',
    delay: 1.4
  },
  // Fonctionnalités en bas
  {
    icon: ChartBar,
    title: 'Statistiques',
    description: 'Analysez la performance de vos investissements',
    position: 'bottom-24 left-[20%]',
    delay: 1.6
  },
  {
    icon: DollarSign,
    title: 'Comptabilité',
    description: 'Suivez vos revenus et dépenses',
    position: 'bottom-12 left-[40%]',
    delay: 1.8
  },
  {
    icon: GraduationCap,
    title: 'Formation',
    description: 'Accédez à des ressources éducatives',
    position: 'bottom-12 right-[40%]',
    delay: 2.0
  },
  {
    icon: ScrollText,
    title: 'Rapports',
    description: 'Générez des rapports détaillés',
    position: 'bottom-24 right-[20%]',
    delay: 2.2
  }
];

// Le reste du composant reste inchangé
const FeatureBackground = () => {
  const [hoveredFeature, setHoveredFeature] = useState<number | null>(null);

  return (
    <div className="fixed inset-0 pointer-events-none">
      {/* Fond dégradé avec animation */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-br from-indigo-50 to-blue-100">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(99,102,241,0.1),transparent)] animate-pulse" />
        </div>
        {/* Cercles décoratifs animés */}
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-indigo-100/30 rounded-full blur-3xl animate-rotate" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-100/30 rounded-full blur-3xl animate-rotate" style={{ animationDirection: 'reverse' }} />
      </div>

      {/* Features flottantes */}
      {features.map((feature, index) => (
        <div
          key={index}
          className={`absolute ${feature.position} pointer-events-auto`}
          style={{
            animation: `float 4s ease-in-out infinite ${feature.delay}s`,
          }}
          onMouseEnter={() => setHoveredFeature(index)}
          onMouseLeave={() => setHoveredFeature(null)}
        >
          <div className={`
            relative group
            transition-all duration-300
            ${hoveredFeature === index ? 'scale-110 z-50' : 'hover:scale-105 z-40'}
          `}>
            <div className={`
              p-2 rounded-2xl
              bg-white/90 backdrop-blur-sm
              border border-indigo-100
              shadow-lg
              transition-all duration-300
              ${hoveredFeature === index ? 'bg-white shadow-xl' : ''}
            `}>
              <div className="flex items-center space-x-2">
                <div className={`
                  p-1.5 rounded-xl
                  ${hoveredFeature === index ? 'bg-indigo-100' : 'bg-indigo-50'}
                  transition-colors duration-300
                `}>
                  <feature.icon className={`
                    w-4 h-4
                    ${hoveredFeature === index ? 'text-indigo-600' : 'text-indigo-500'}
                    transition-colors duration-300
                  `} />
                </div>
                <span className={`
                  text-xs font-medium whitespace-nowrap
                  ${hoveredFeature === index ? 'text-gray-900' : 'text-gray-700'}
                  transition-colors duration-300
                `}>
                  {feature.title}
                </span>
              </div>
            </div>

            {/* Tooltip de description */}
            <div className={`
              absolute ${index < 6 ? 'top-full' : 'bottom-full'} left-1/2 -translate-x-1/2 ${index < 6 ? 'mt-2' : 'mb-2'}
              px-3 py-1.5 rounded-lg
              bg-white shadow-lg border border-gray-100
              text-xs text-gray-600
              opacity-0 invisible
              transition-all duration-300
              ${hoveredFeature === index ? 'opacity-100 visible translate-y-0' : index < 6 ? 'translate-y-2' : '-translate-y-2'}
              z-50 min-w-[180px] text-center
            `}>
              {feature.description}
              <div className={`
                absolute ${index < 6 ? '-top-2' : '-bottom-2'} left-1/2 -translate-x-1/2 
                w-4 h-4 bg-white border-t border-l border-gray-100 
                transform ${index < 6 ? 'rotate-45' : '-rotate-135'}
              `} />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default FeatureBackground;