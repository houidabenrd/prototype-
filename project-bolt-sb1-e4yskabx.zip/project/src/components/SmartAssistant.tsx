import React, { useState, useEffect } from 'react';
import { Brain, MessageCircle, X, ChevronDown, ChevronUp, Info, Star, Calculator, ArrowRight, TrendingUp, Sparkles } from 'lucide-react';

interface SmartAssistantProps {
  userName: string;
  usageStats: {
    totalSpent: number;
    servicesUsed: {
      name: string;
      count: number;
      cost: number;
    }[];
  };
  onClose: () => void;
}

const SmartAssistant: React.FC<SmartAssistantProps> = ({ userName, usageStats, onClose }) => {
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<Array<{
    type: 'system' | 'user' | 'assistant';
    content: string;
    timestamp: Date;
  }>>([]);
  const [userInput, setUserInput] = useState('');

  // Calculer les économies potentielles
  const calculateSavings = () => {
    const yearlyProjection = usageStats.totalSpent * 12;
    const starterCost = 199;
    return yearlyProjection - starterCost;
  };

  // Générer des recommandations personnalisées
  const generateRecommendations = () => {
    const recommendations = [];
    const mostUsedService = usageStats.servicesUsed.reduce((prev, current) => 
      current.count > prev.count ? current : prev
    );

    recommendations.push({
      type: 'usage',
      message: `J'ai remarqué que vous utilisez fréquemment ${mostUsedService.name}. Avec Starter, vous économiseriez ${(mostUsedService.cost * 0.4).toFixed(2)}$ par utilisation.`
    });

    if (usageStats.totalSpent > 50) {
      recommendations.push({
        type: 'savings',
        message: `Vos dépenses actuelles projettent un coût annuel de ${(usageStats.totalSpent * 12).toFixed(2)}$. Starter à 199$/an vous ferait économiser ${calculateSavings().toFixed(2)}$!`
      });
    }

    return recommendations;
  };

  useEffect(() => {
    // Messages initiaux
    const initialMessages = [
      {
        content: `👋 Bonjour ${userName}! Je suis votre assistant IA.`,
        delay: 1000
      },
      {
        content: "Je suis là pour vous aider à optimiser votre utilisation de la plateforme.",
        delay: 2000
      },
      {
        content: generateRecommendations()[0].message,
        delay: 3000
      }
    ];

    initialMessages.forEach((msg, index) => {
      setTimeout(() => {
        setMessages(prev => [...prev, {
          type: 'assistant',
          content: msg.content,
          timestamp: new Date()
        }]);
      }, msg.delay);
    });
  }, []);

  const handleSendMessage = () => {
    if (!userInput.trim()) return;

    setMessages(prev => [...prev, {
      type: 'user',
      content: userInput,
      timestamp: new Date()
    }]);

    setUserInput('');

    // Simuler une réponse de l'IA
    setTimeout(() => {
      const recommendations = generateRecommendations();
      const response = recommendations[Math.floor(Math.random() * recommendations.length)].message;
      
      setMessages(prev => [...prev, {
        type: 'assistant',
        content: response,
        timestamp: new Date()
      }]);
    }, 1000);
  };

  return (
    <div className={`
      fixed bottom-4 right-4 w-96 bg-white rounded-xl shadow-xl border border-indigo-200 z-50
      transition-all duration-300 transform
      ${isMinimized ? 'h-14' : 'h-[500px]'}
    `}>
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-t-xl">
        <div className="flex items-center space-x-2">
          <Brain className="h-5 w-5" />
          <span className="font-medium">Assistant IA</span>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setIsMinimized(!isMinimized)}
            className="p-1 hover:bg-white/10 rounded-lg transition-colors"
          >
            {isMinimized ? (
              <ChevronUp className="h-5 w-5" />
            ) : (
              <ChevronDown className="h-5 w-5" />
            )}
          </button>
          <button
            onClick={onClose}
            className="p-1 hover:bg-white/10 rounded-lg transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
      </div>

      {/* Messages */}
      {!isMinimized && (
        <>
          <div className="flex-1 overflow-y-auto p-4 space-y-4 h-[400px]">
            {messages.map((message, index) => (
              <div
                key={index}
                className={`
                  flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}
                  animate-fadeIn
                `}
              >
                <div className={`
                  max-w-[80%] rounded-lg p-3 
                  ${message.type === 'user'
                    ? 'bg-indigo-600 text-white'
                    : 'bg-gray-100 text-gray-900'
                  }
                `}>
                  {message.content}
                </div>
              </div>
            ))}
          </div>

          {/* Input */}
          <div className="p-4 border-t border-gray-200">
            <div className="flex space-x-2">
              <input
                type="text"
                value={userInput}
                onChange={(e) => setUserInput(e.target.value)}
                placeholder="Posez une question sur le forfait Starter..."
                className="flex-1 px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              />
              <button
                onClick={handleSendMessage}
                className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
              >
                Envoyer
              </button>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="p-4 bg-gray-50 border-t border-gray-200 rounded-b-xl">
            <div className="flex space-x-2">
              <button
                onClick={() => {
                  setMessages(prev => [...prev, {
                    type: 'user',
                    content: 'Calculer mes économies',
                    timestamp: new Date()
                  }]);
                  setTimeout(() => {
                    setMessages(prev => [...prev, {
                      type: 'assistant',
                      content: `Avec votre utilisation actuelle, vous économiseriez ${calculateSavings().toFixed(2)}$ par an avec Starter!`,
                      timestamp: new Date()
                    }]);
                  }, 1000);
                }}
                className="flex-1 px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm text-gray-700 hover:bg-gray-50 transition-colors flex items-center justify-center"
              >
                <Calculator className="h-4 w-4 mr-2" />
                Calculer mes économies
              </button>
              <button
                className="flex-1 px-3 py-2 bg-indigo-600 text-white rounded-lg text-sm hover:bg-indigo-700 transition-colors flex items-center justify-center"
              >
                <Sparkles className="h-4 w-4 mr-2" />
                Passer à Starter
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default SmartAssistant;