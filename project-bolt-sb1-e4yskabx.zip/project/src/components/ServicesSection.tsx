import React from 'react';
import {
  FileText, Scale, PieChart, BookOpen, HeartHandshake, 
  ShieldCheck, GraduationCap, Users2, Handshake, 
  Building, ScrollText, BarChart3, Mail, Briefcase
} from 'lucide-react';

const services = [
  {
    title: 'Gestion locative',
    icon: Building,
    features: [
      { title: 'Enquêtes pré-location', description: 'Vérification du dossier de crédit, historique locatif et références' },
      { title: 'Baux électroniques', description: 'Génération et gestion de baux conformes' },
      { title: 'Renouvellement de baux', description: 'Gestion des avis de reconduction et modifications' },
      { title: 'Modèles de lettres', description: 'Outils pour générer des avis légaux' },
      { title: 'Recommandés électroniques', description: 'Envoi sécurisé avec preuve de réception' }
    ]
  },
  {
    title: 'Outils financiers et statistiques',
    icon: BarChart3,
    features: [
      { title: 'Calculateur de rentabilité', description: 'Analyse des revenus et dépenses' },
      { title: 'Gestion financière', description: 'Suivi des paiements et coûts' },
      { title: 'Statistiques du marché', description: 'Données sur les loyers et tendances' },
      { title: 'Rapports personnalisés', description: 'Création de rapports détaillés' }
    ]
  },
  {
    title: 'Services juridiques et conseils',
    icon: Scale,
    features: [
      { title: 'Support juridique', description: 'Conseils sur les lois locatives' },
      { title: 'Assistance litiges', description: 'Soutien pour les dossiers TAL' },
      { title: 'Consultations', description: 'Conseils personnalisés d\'experts' }
    ]
  },
  {
    title: 'Formation et information',
    icon: GraduationCap,
    features: [
      { title: 'Ateliers et formations', description: 'Sessions éducatives pratiques' },
      { title: 'Webinaires', description: 'Présentations en ligne thématiques' },
      { title: 'Actualités', description: 'Informations sur la législation' }
    ]
  },
  {
    title: 'Avantages et partenariats',
    icon: Handshake,
    features: [
      { title: 'Répertoire partenaires', description: 'Services à tarifs préférentiels' },
      { title: 'Assurance propriétaire', description: 'Programmes exclusifs membres' },
      { title: 'Rabais membres', description: 'Économies sur les services' }
    ]
  },
  {
    title: 'Plaidoyer et défense',
    icon: ShieldCheck,
    features: [
      { title: 'Représentation', description: 'Défense des droits des propriétaires' },
      { title: 'Propositions législatives', description: 'Participation aux débats' },
      { title: 'Suivi réglementaire', description: 'Mises à jour des lois' }
    ]
  }
];

const ServicesSection = () => {
  return (
    <div className="py-12">
      <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
        Nos services principaux
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {services.map((service) => (
          <div key={service.title} className="bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow p-6 border border-gray-100">
            <div className="flex items-center mb-6">
              <div className="p-3 bg-indigo-100 rounded-lg">
                <service.icon className="w-6 h-6 text-indigo-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 ml-4">
                {service.title}
              </h3>
            </div>
            <ul className="space-y-4">
              {service.features.map((feature) => (
                <li key={feature.title} className="flex items-start">
                  <div className="flex-shrink-0 h-6 w-6 text-indigo-600">
                    <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-gray-900">{feature.title}</p>
                    <p className="text-sm text-gray-500">{feature.description}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ServicesSection;