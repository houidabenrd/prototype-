import React, { useState } from 'react';
import { X, FileText, Check, Clock, Download, Search, Filter, Calendar, ArrowRight, DollarSign, Receipt, FileBarChart, AlertTriangle } from 'lucide-react';

interface Invoice {
  id: string;
  date: string;
  description: string;
  amount: number;
  status: 'paid' | 'pending' | 'failed';
  service: string;
  downloadUrl: string;
}

interface InvoicesPopupProps {
  isOpen: boolean;
  onClose: () => void;
}

const InvoicesPopup: React.FC<InvoicesPopupProps> = ({ isOpen, onClose }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedService, setSelectedService] = useState<string | 'all'>('all');
  const [selectedStatus, setSelectedStatus] = useState<string | 'all'>('all');
  const [selectedPeriod, setSelectedPeriod] = useState<string>('month');

  // Exemple de données de factures
  const invoices: Invoice[] = [
    {
      id: 'INV-2024-001',
      date: '2024-02-15',
      description: 'Enquête pré-location - 123 Rue de Paris',
      amount: 49.99,
      status: 'paid',
      service: 'Enquêtes',
      downloadUrl: '#'
    },
    {
      id: 'INV-2024-002',
      date: '2024-02-14',
      description: 'Bail électronique - Studio Montmartre',
      amount: 39.99,
      status: 'paid',
      service: 'Baux',
      downloadUrl: '#'
    },
    {
      id: 'INV-2024-003',
      date: '2024-02-13',
      description: 'Publication d\'annonce - T2 Centre-ville',
      amount: 29.99,
      status: 'paid',
      service: 'Annonces',
      downloadUrl: '#'
    },
    {
      id: 'INV-2024-004',
      date: '2024-02-12',
      description: 'Recommandé électronique - Mise en demeure',
      amount: 14.99,
      status: 'pending',
      service: 'Recommandés',
      downloadUrl: '#'
    }
  ];

  // Filtrer les factures
  const filteredInvoices = invoices.filter(invoice => {
    const matchesSearch = invoice.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         invoice.id.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesService = selectedService === 'all' || invoice.service === selectedService;
    const matchesStatus = selectedStatus === 'all' || invoice.status === selectedStatus;
    return matchesSearch && matchesService && matchesStatus;
  });

  // Calculer les statistiques
  const stats = {
    total: filteredInvoices.reduce((sum, inv) => sum + inv.amount, 0),
    count: filteredInvoices.length,
    pending: filteredInvoices.filter(inv => inv.status === 'pending').reduce((sum, inv) => sum + inv.amount, 0),
    lastPayment: new Date(Math.max(...filteredInvoices.map(inv => new Date(inv.date).getTime())))
  };

  // Calculer les économies potentielles
  const calculatePotentialSavings = () => {
    const monthlyTotal = stats.total;
    const yearlyProjection = monthlyTotal * 12;
    const starterPrice = 199;
    return yearlyProjection - starterPrice;
  };

  const services = Array.from(new Set(invoices.map(inv => inv.service)));

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl max-w-4xl w-full mx-4 relative max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-gray-200 sticky top-0 bg-white z-10">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Historique des factures</h2>
              <p className="mt-1 text-sm text-gray-500">
                Consultez et téléchargez vos factures
              </p>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-500 transition-colors"
            >
              <X className="h-6 w-6" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-auto p-6">
          <div className="space-y-6">
            {/* Statistiques */}
            <div className="grid grid-cols-4 gap-4">
              <div className="bg-white p-4 rounded-lg border border-gray-200">
                <div className="flex items-center justify-between">
                  <div className="p-2 bg-indigo-50 rounded-lg">
                    <DollarSign className="h-5 w-5 text-indigo-600" />
                  </div>
                  <span className="text-sm text-gray-500">Total des factures</span>
                </div>
                <div className="mt-2">
                  <div className="text-2xl font-bold text-gray-900">
                    {stats.total.toFixed(2)}$
                  </div>
                  <div className="text-sm text-gray-500">
                    ce mois-ci
                  </div>
                </div>
              </div>

              <div className="bg-white p-4 rounded-lg border border-gray-200">
                <div className="flex items-center justify-between">
                  <div className="p-2 bg-green-50 rounded-lg">
                    <Receipt className="h-5 w-5 text-green-600" />
                  </div>
                  <span className="text-sm text-gray-500">Nombre de factures</span>
                </div>
                <div className="mt-2">
                  <div className="text-2xl font-bold text-gray-900">
                    {stats.count}
                  </div>
                  <div className="text-sm text-gray-500">
                    transactions
                  </div>
                </div>
              </div>

              <div className="bg-white p-4 rounded-lg border border-gray-200">
                <div className="flex items-center justify-between">
                  <div className="p-2 bg-amber-50 rounded-lg">
                    <Clock className="h-5 w-5 text-amber-600" />
                  </div>
                  <span className="text-sm text-gray-500">En attente</span>
                </div>
                <div className="mt-2">
                  <div className="text-2xl font-bold text-gray-900">
                    {stats.pending.toFixed(2)}$
                  </div>
                  <div className="text-sm text-gray-500">
                    à payer
                  </div>
                </div>
              </div>

              <div className="bg-white p-4 rounded-lg border border-gray-200">
                <div className="flex items-center justify-between">
                  <div className="p-2 bg-blue-50 rounded-lg">
                    <FileBarChart className="h-5 w-5 text-blue-600" />
                  </div>
                  <span className="text-sm text-gray-500">Dernier paiement</span>
                </div>
                <div className="mt-2">
                  <div className="text-2xl font-bold text-gray-900">
                    {stats.lastPayment.toLocaleDateString('fr-FR')}
                  </div>
                  <div className="text-sm text-gray-500">
                    dernière transaction
                  </div>
                </div>
              </div>
            </div>

            {/* Alerte d'économies */}
            {calculatePotentialSavings() > 0 && (
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                <div className="flex items-start">
                  <AlertTriangle className="h-5 w-5 text-amber-600 mt-0.5" />
                  <div className="ml-3">
                    <h3 className="text-sm font-medium text-amber-800">
                      Économisez sur vos factures !
                    </h3>
                    <p className="mt-1 text-sm text-amber-700">
                      Avec une projection annuelle de {(stats.total * 12).toFixed(2)}$, 
                      vous pourriez économiser {calculatePotentialSavings().toFixed(2)}$ 
                      avec le forfait Starter à 199$/an.
                    </p>
                    <button className="mt-2 inline-flex items-center px-3 py-1.5 bg-amber-600 text-white text-sm font-medium rounded-lg hover:bg-amber-700">
                      Passer à Starter
                      <ArrowRight className="ml-1.5 h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Filtres */}
            <div className="flex items-center space-x-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Rechercher une facture..."
                  className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                />
              </div>

              <select
                value={selectedService}
                onChange={(e) => setSelectedService(e.target.value)}
                className="px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              >
                <option value="all">Tous les services</option>
                {services.map(service => (
                  <option key={service} value={service}>{service}</option>
                ))}
              </select>

              <select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
                className="px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              >
                <option value="all">Tous les statuts</option>
                <option value="paid">Payée</option>
                <option value="pending">En attente</option>
                <option value="failed">Échouée</option>
              </select>

              <select
                value={selectedPeriod}
                onChange={(e) => setSelectedPeriod(e.target.value)}
                className="px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              >
                <option value="month">Ce mois</option>
                <option value="quarter">Ce trimestre</option>
                <option value="year">Cette année</option>
              </select>
            </div>

            {/* Table */}
            <div className="bg-white shadow-sm rounded-lg border border-gray-200">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Facture
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Date
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Service
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Montant
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Statut
                    </th>
                    <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredInvoices.map((invoice) => (
                    <tr key={invoice.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <FileText className="h-5 w-5 text-gray-400 mr-2" />
                          <div className="text-sm font-medium text-gray-900">{invoice.id}</div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">
                          {new Date(invoice.date).toLocaleDateString('fr-FR')}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{invoice.service}</div>
                        <div className="text-xs text-gray-500">{invoice.description}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">
                          {invoice.amount.toFixed(2)}$
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`
                          inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                          ${invoice.status === 'paid'
                            ? 'bg-green-100 text-green-800'
                            : invoice.status === 'pending'
                              ? 'bg-yellow-100 text-yellow-800'
                              : 'bg-red-100 text-red-800'
                          }
                        `}>
                          {invoice.status === 'paid' ? (
                            <>
                              <Check className="w-3 h-3 mr-1" />
                              Payée
                            </>
                          ) : invoice.status === 'pending' ? (
                            <>
                              <Clock className="w-3 h-3 mr-1" />
                              En attente
                            </>
                          ) : (
                            <>
                              <AlertTriangle className="w-3 h-3 mr-1" />
                              Échouée
                            </>
                          )}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right">
                        <button 
                          className="inline-flex items-center px-3 py-1.5 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                        >
                          <Download className="h-4 w-4 mr-1" />
                          PDF
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InvoicesPopup;