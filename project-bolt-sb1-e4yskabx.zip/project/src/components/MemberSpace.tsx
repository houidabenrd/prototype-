import React, { useState } from 'react';
import { Newspaper, Calendar, GraduationCap, ArrowRight, Info, Star, Lock, Sparkles } from 'lucide-react';
import StarterFeaturePopup from './StarterFeaturePopup';

interface MemberSpaceProps {
  onShowNews: () => void;
  onShowCalendar: () => void;
}

const services = [
  {
    id: 'actualites',
    icon: Newspaper,
    title: 'Actualité',
    description: 'Découvrez les dernières informations et mises à jour',
    type: 'limited',
    limit: 3,
    features: [
      'Articles exclusifs',
      'Analyses de marché',
      'Veille juridique'
    ],
    starterBenefit: 'Accès illimité aux articles'
  },
  {
    id: 'evenements',
    icon: Calendar,
    title: 'Événements',
    description: 'Participez aux événements exclusifs',
    type: 'pay-per-use',
    price: 19.99,
    starterPrice: 9.99,
    features: [
      'Conférences thématiques',
      'Networking',
      'Ateliers pratiques'
    ],
    starterBenefit: '50% de réduction sur les inscriptions'
  },
  {
    id: 'formations',
    icon: GraduationCap,
    title: 'Formations',
    description: 'Approfondissez vos connaissances',
    type: 'pay-per-use',
    price: 79.99,
    starterPrice: 49.99,
    features: [
      'Formations en ligne',
      'Certification officielle',
      'Support personnalisé'
    ],
    starterBenefit: 'Tarifs préférentiels sur toutes les formations'
  }
];

const MemberSpace: React.FC<MemberSpaceProps> = ({ onShowNews, onShowCalendar }) => {
  const [showFeaturePopup, setShowFeaturePopup] = useState(false);
  const [selectedFeature, setSelectedFeature] = useState<typeof services[0] | null>(null);

  const handleServiceClick = (service: typeof services[0]) => {
    if (service.id === 'actualites') {
      onShowNews();
    } else if (service.id === 'evenements') {
      onShowCalendar();
    } else {
      setSelectedFeature(service);
      setShowFeaturePopup(true);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Espace Membre</h2>
          <p className="mt-1 text-gray-600">Explorez nos services exclusifs</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {services.map((service) => (
          <div
            key={service.id}
            onClick={() => handleServiceClick(service)}
            className={`
              bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden
              cursor-pointer
              transition-all duration-300 hover:scale-[1.02] hover:shadow-md
              group relative
            `}
          >
            {/* Service Badge */}
            <div className="absolute top-3 right-3 text-xs px-2 py-1 rounded-full transform rotate-3 z-10 flex items-center">
              {service.type === 'limited' ? (
                <div className="bg-amber-100 text-amber-800 border border-amber-200">
                  {service.limit} articles gratuits
                </div>
              ) : (
                <div className="bg-blue-100 text-blue-800 border border-blue-200">
                  Paiement à la pièce
                </div>
              )}
            </div>

            <div className="p-6">
              <div className="flex items-start space-x-4">
                <div className={`p-3 rounded-xl ${
                  service.type === 'limited' ? 'bg-amber-50' : 'bg-blue-50'
                }`}>
                  <service.icon className={`h-6 w-6 ${
                    service.type === 'limited' ? 'text-amber-600' : 'text-blue-600'
                  }`} />
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-gray-900">{service.title}</h3>
                  <p className="mt-1 text-sm text-gray-600">{service.description}</p>
                </div>
              </div>

              {service.type === 'pay-per-use' && (
                <div className="mt-4">
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-bold text-gray-900">
                      {service.price}$
                    </span>
                    <div className="text-right">
                      <span className="text-sm text-gray-500">par utilisation</span>
                      <div className="text-xs text-green-600">
                        {service.starterPrice}$ avec Starter
                      </div>
                    </div>
                  </div>
                </div>
              )}

              <div className="mt-6 space-y-3">
                {service.features.map((feature, index) => (
                  <div key={index} className="flex items-center text-sm text-gray-600">
                    <Star className={`h-4 w-4 mr-2 ${
                      service.type === 'limited' ? 'text-amber-400' : 'text-blue-400'
                    }`} />
                    {feature}
                  </div>
                ))}
              </div>

              <div className="mt-6 p-3 bg-gray-50 rounded-lg border border-gray-200">
                <div className="flex items-center text-sm text-gray-600">
                  <Info className="h-4 w-4 mr-2 text-indigo-600" />
                  <span>{service.starterBenefit} avec Starter</span>
                </div>
              </div>

              <button className={`
                mt-6 w-full inline-flex items-center justify-center px-4 py-2 rounded-lg
                ${service.type === 'limited'
                  ? 'bg-amber-600 hover:bg-amber-700'
                  : 'bg-blue-600 hover:bg-blue-700'
                }
                text-white transition-colors
              `}>
                {service.type === 'limited' ? 'Voir les actualités' : 'Explorer'}
                <ArrowRight className="ml-2 h-4 w-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Promo Banner */}
      <div className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 rounded-xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-2xl font-bold mb-2">
              Débloquez tout le potentiel de votre gestion immobilière
            </h3>
            <p className="text-lg text-indigo-100">
              Passez au forfait Starter pour seulement 199$/an et accédez à toutes les fonctionnalités
            </p>
          </div>
          <button className="px-8 py-4 bg-white text-indigo-600 rounded-xl font-medium hover:bg-indigo-50 transition-colors flex items-center">
            Passer au forfait Starter
            <ArrowRight className="ml-2 h-5 w-5" />
          </button>
        </div>
      </div>

      {/* Starter Feature Popup */}
      {selectedFeature && (
        <StarterFeaturePopup
          isOpen={showFeaturePopup}
          onClose={() => setShowFeaturePopup(false)}
          feature={{
            title: selectedFeature.title,
            description: selectedFeature.description
          }}
        />
      )}
    </div>
  );
};

export default MemberSpace;