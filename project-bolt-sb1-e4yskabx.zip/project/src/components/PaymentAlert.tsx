import React, { useState, useEffect } from 'react';
import { AlertTriangle, X, ArrowRight, Calculator } from 'lucide-react';

interface PaymentAlertProps {
  amount: number;
  service: string;
  onClose: () => void;
}

const PaymentAlert: React.FC<PaymentAlertProps> = ({ amount, service, onClose }) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
    const timer = setTimeout(() => {
      setIsVisible(false);
      setTimeout(onClose, 300); // Allow time for exit animation
    }, 5000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className={`
      fixed bottom-4 right-4 max-w-md w-full bg-white rounded-lg shadow-lg border border-amber-200 p-4
      transform transition-all duration-300
      ${isVisible ? 'translate-x-0 opacity-100' : 'translate-x-full opacity-0'}
    `}>
      <div className="flex items-start">
        <div className="flex-shrink-0">
          <AlertTriangle className="h-5 w-5 text-amber-600" />
        </div>
        <div className="ml-3 flex-1">
          <div className="text-sm font-medium text-amber-800">
            Vous venez de payer {amount.toFixed(2)}$ pour {service}
          </div>
          <p className="mt-1 text-sm text-amber-700">
            Cette action aurait été incluse gratuitement avec le forfait Starter !
          </p>
          <div className="mt-3 flex items-center justify-between">
            <button
              className="inline-flex items-center px-3 py-1.5 text-sm font-medium text-indigo-600 hover:text-indigo-500"
            >
              <Calculator className="h-4 w-4 mr-1" />
              Calculer mes économies
            </button>
            <button
              className="inline-flex items-center px-3 py-1.5 bg-indigo-600 text-white text-sm font-medium rounded-lg hover:bg-indigo-700"
            >
              Passer à Starter
              <ArrowRight className="ml-1.5 h-4 w-4" />
            </button>
          </div>
        </div>
        <button
          onClick={() => {
            setIsVisible(false);
            setTimeout(onClose, 300);
          }}
          className="flex-shrink-0 ml-3 text-amber-500 hover:text-amber-600"
        >
          <X className="h-5 w-5" />
        </button>
      </div>
    </div>
  );
};

export default PaymentAlert;