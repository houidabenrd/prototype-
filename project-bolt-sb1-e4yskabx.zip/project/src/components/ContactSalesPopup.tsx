import React, { useState } from 'react';
import { X, Calendar, Clock, User, Phone, Mail, Building2, Info, ChevronLeft, ChevronRight, Check, MapPin, Star, Shield, ArrowRight, Users2 } from 'lucide-react';

interface ContactSalesPopupProps {
  isOpen: boolean;
  onClose: () => void;
}

const ContactSalesPopup: React.FC<ContactSalesPopupProps> = ({ isOpen, onClose }) => {
  const [step, setStep] = useState(1);
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    company: '',
    unitsCount: '',
    message: '',
    preferredContact: 'phone' as 'phone' | 'email' | 'both'
  });

  if (!isOpen) return null;

  // Générer les dates disponibles (prochains 14 jours ouvrables)
  const getAvailableDates = () => {
    const dates = [];
    const today = new Date();
    let current = new Date(today);

    while (dates.length < 14) {
      if (current.getDay() !== 0 && current.getDay() !== 6) { // Exclure weekends
        dates.push(new Date(current));
      }
      current.setDate(current.getDate() + 1);
    }
    return dates;
  };

  // Générer les créneaux horaires disponibles
  const getAvailableTimes = () => {
    return [
      { time: '09:00', label: '9h00', available: true },
      { time: '09:30', label: '9h30', available: true },
      { time: '10:00', label: '10h00', available: true },
      { time: '10:30', label: '10h30', available: false },
      { time: '11:00', label: '11h00', available: true },
      { time: '11:30', label: '11h30', available: true },
      { time: '14:00', label: '14h00', available: true },
      { time: '14:30', label: '14h30', available: true },
      { time: '15:00', label: '15h00', available: true },
      { time: '15:30', label: '15h30', available: true },
      { time: '16:00', label: '16h00', available: true },
      { time: '16:30', label: '16h30', available: false }
    ];
  };

  const handleSubmit = () => {
    // Ici, vous implémenteriez la logique pour enregistrer le rendez-vous
    console.log('Rendez-vous programmé:', {
      date: selectedDate,
      time: selectedTime,
      ...formData
    });
    onClose();
  };

  const isStepValid = () => {
    switch (step) {
      case 1:
        return selectedDate && selectedTime;
      case 2:
        return formData.firstName && formData.lastName && formData.email && formData.phone;
      default:
        return true;
    }
  };

  const renderStepIndicator = () => (
    <div className="px-6 pt-4">
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center">
          <div className={`
            w-10 h-10 rounded-full flex items-center justify-center
            ${step === 1 ? 'bg-indigo-600 text-white' : 'bg-indigo-100 text-indigo-600'}
          `}>
            <Calendar className="h-5 w-5" />
          </div>
          <div className="ml-3">
            <p className={`text-sm font-medium ${step === 1 ? 'text-indigo-600' : 'text-gray-500'}`}>
              Date et heure
            </p>
          </div>
        </div>
        <div className="flex-1 mx-4">
          <div className="h-1 bg-gray-200 rounded">
            <div 
              className="h-full bg-indigo-600 rounded transition-all duration-300"
              style={{ width: `${(step / 2) * 100}%` }}
            />
          </div>
        </div>
        <div className="flex items-center">
          <div className={`
            w-10 h-10 rounded-full flex items-center justify-center
            ${step === 2 ? 'bg-indigo-600 text-white' : 'bg-indigo-100 text-indigo-600'}
          `}>
            <User className="h-5 w-5" />
          </div>
          <div className="ml-3">
            <p className={`text-sm font-medium ${step === 2 ? 'text-indigo-600' : 'text-gray-500'}`}>
              Vos informations
            </p>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl max-w-4xl w-full mx-4 relative max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="p-6 border-b border-gray-200 sticky top-0 bg-white z-10">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-gray-400 hover:text-gray-500"
          >
            <X className="h-6 w-6" />
          </button>
          <div className="pr-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-2">
              Planifier un rendez-vous
            </h2>
            <p className="text-gray-600">
              Discutez avec un chargé de compte pour une solution adaptée à vos besoins
            </p>
          </div>
        </div>

        {renderStepIndicator()}

        {/* Content */}
        <div className="p-6">
          {step === 1 ? (
            <div className="space-y-8">
              {/* Calendar */}
              <div className="bg-white rounded-xl shadow-sm border border-gray-200">
                <div className="flex items-center justify-between p-4 border-b border-gray-200">
                  <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                    <ChevronLeft className="h-5 w-5 text-gray-600" />
                  </button>
                  <span className="text-lg font-medium text-gray-900">
                    {selectedDate ? selectedDate.toLocaleString('fr-FR', { month: 'long', year: 'numeric' }) : new Date().toLocaleString('fr-FR', { month: 'long', year: 'numeric' })}
                  </span>
                  <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                    <ChevronRight className="h-5 w-5 text-gray-600" />
                  </button>
                </div>
                <div className="p-4">
                  <div className="grid grid-cols-7 gap-1 mb-4">
                    {['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'].map((day) => (
                      <div key={day} className="text-center text-sm font-medium text-gray-600 py-2">
                        {day}
                      </div>
                    ))}
                  </div>
                  <div className="grid grid-cols-7 gap-1">
                    {getAvailableDates().map((date, index) => (
                      <button
                        key={index}
                        onClick={() => setSelectedDate(date)}
                        disabled={date < new Date()}
                        className={`
                          p-2 rounded-lg text-sm font-medium
                          ${selectedDate?.toDateString() === date.toDateString()
                            ? 'bg-indigo-600 text-white'
                            : date < new Date()
                              ? 'text-gray-300 cursor-not-allowed'
                              : 'hover:bg-indigo-50 text-gray-700'
                          }
                        `}
                      >
                        {date.getDate()}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Time Slots */}
              {selectedDate && (
                <div className="space-y-4">
                  <h3 className="text-lg font-medium text-gray-900 flex items-center">
                    <Clock className="h-5 w-5 mr-2 text-indigo-600" />
                    Créneaux disponibles
                  </h3>
                  <div className="grid grid-cols-3 gap-3">
                    {getAvailableTimes().map(({ time, label, available }) => (
                      <button
                        key={time}
                        onClick={() => setSelectedTime(time)}
                        disabled={!available}
                        className={`
                          py-3 px-4 rounded-lg text-sm font-medium
                          transition-all duration-200
                          ${selectedTime === time
                            ? 'bg-indigo-600 text-white shadow-lg scale-105'
                            : !available
                              ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                              : 'border border-gray-200 hover:border-indigo-500 hover:bg-indigo-50'
                          }
                        `}
                      >
                        {label}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-6">
              {/* Contact Form */}
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Prénom
                  </label>
                  <input
                    type="text"
                    value={formData.firstName}
                    onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Nom
                  </label>
                  <input
                    type="text"
                    value={formData.lastName}
                    onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Email professionnel
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Téléphone
                </label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Entreprise
                </label>
                <div className="relative">
                  <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <input
                    type="text"
                    value={formData.company}
                    onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Nombre de logements
                </label>
                <div className="relative">
                  <Users2 className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <input
                    type="number"
                    value={formData.unitsCount}
                    onChange={(e) => setFormData({ ...formData, unitsCount: e.target.value })}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Message (optionnel)
                </label>
                <textarea
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  rows={3}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="Décrivez vos besoins spécifiques..."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Mode de contact préféré
                </label>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { value: 'phone', label: 'Téléphone', icon: Phone },
                    { value: 'email', label: 'Email', icon: Mail },
                    { value: 'both', label: 'Les deux', icon: Check }
                  ].map(({ value, label, icon: Icon }) => (
                    <button
                      key={value}
                      type="button"
                      onClick={() => setFormData({ ...formData, preferredContact: value as 'phone' | 'email' | 'both' })}
                      className={`
                        flex items-center justify-center space-x-2 py-2 px-4 rounded-lg
                        ${formData.preferredContact === value
                          ? 'bg-indigo-600 text-white'
                          : 'border border-gray-300 text-gray-700 hover:bg-gray-50'
                        }
                      `}
                    >
                      <Icon className="h-4 w-4" />
                      <span>{label}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-6 bg-gray-50 border-t border-gray-200 sticky bottom-0">
          <div className="flex items-center justify-between">
            <button
              onClick={() => step === 1 ? onClose() : setStep(1)}
              className="px-4 py-2 text-gray-600 hover:text-gray-900"
            >
              {step === 1 ? 'Annuler' : 'Retour'}
            </button>
            <button
              onClick={() => step === 1 ? setStep(2) : handleSubmit()}
              disabled={!isStepValid()}
              className={`
                flex items-center px-6 py-2 rounded-lg font-medium
                ${isStepValid()
                  ? 'bg-indigo-600 text-white hover:bg-indigo-700'
                  : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                }
              `}
            >
              {step === 1 ? (
                <>
                  Continuer
                  <ArrowRight className="ml-2 h-5 w-5" />
                </>
              ) : (
                'Confirmer le rendez-vous'
              )}
            </button>
          </div>
        </div>

        {/* Info Banner */}
        <div className="p-6 bg-indigo-50 rounded-b-xl">
          <div className="flex items-start space-x-3">
            <Info className="h-5 w-5 text-indigo-600 mt-0.5" />
            <div className="space-y-2">
              <p className="text-sm text-indigo-700">
                Un chargé de compte vous contactera pour confirmer le rendez-vous et préparer un devis personnalisé adapté à vos besoins.
              </p>
              <div className="flex items-center space-x-4">
                <div className="flex items-center text-sm text-indigo-700">
                  <Shield className="h-4 w-4 mr-1" />
                  <span>Données sécurisées</span>
                </div>
                <div className="flex items-center text-sm text-indigo-700">
                  <Star className="h-4 w-4 mr-1" />
                  <span>Service prioritaire</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactSalesPopup;