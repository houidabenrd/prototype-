import React, { useState, useEffect } from 'react';
import { MessageCircle, X, ChevronDown, ChevronUp, Info, Star, ShoppingCart, Calendar } from 'lucide-react';

interface Message {
  id: string;
  type: 'system' | 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

interface ChatTutorialProps {
  userName: string;
  onClose: () => void;
}

const ChatTutorial: React.FC<ChatTutorialProps> = ({ userName, onClose }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isMinimized, setIsMinimized] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [userInput, setUserInput] = useState('');

  const addMessage = (content: string, type: 'system' | 'user' | 'assistant') => {
    setMessages(prev => [...prev, {
      id: Math.random().toString(36).substr(2, 9),
      type,
      content,
      timestamp: new Date()
    }]);
  };

  const handleSendMessage = () => {
    if (!userInput.trim()) return;

    addMessage(userInput, 'user');
    setUserInput('');

    // Simuler une réponse de l'assistant
    setTimeout(() => {
      addMessage("Je vais vous aider à explorer ce service. Que souhaitez-vous savoir en particulier ?", 'assistant');
    }, 1000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  useEffect(() => {
    const initialMessages = [
      {
        content: `👋 Bonjour ${userName} ! Je suis votre assistant virtuel.`,
        delay: 1000
      },
      {
        content: "Je suis là pour vous aider à découvrir notre plateforme. Voici les services que vous pouvez explorer :",
        delay: 2000
      },
      {
        content: "📋 Cycle de location :\n• Annonces\n• Enquêtes pré-location\n• Baux électroniques",
        delay: 3000
      },
      {
        content: "👥 Espace membre :\n• Événements\n• Formations",
        delay: 4000
      },
      {
        content: "📬 Communication :\n• Recommandés électroniques",
        delay: 5000
      },
      {
        content: "Quel service souhaitez-vous explorer en priorité ?",
        delay: 6000
      }
    ];

    initialMessages.forEach((msg, index) => {
      setTimeout(() => {
        addMessage(msg.content, 'assistant');
      }, msg.delay);
    });
  }, []);

  return (
    <div className={`
      fixed bottom-4 right-4 w-96 bg-white rounded-xl shadow-xl border border-gray-200 z-50
      transition-all duration-300 transform
      ${isMinimized ? 'h-14' : 'h-[500px]'}
    `}>
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-200">
        <div className="flex items-center space-x-2">
          <MessageCircle className="h-5 w-5 text-indigo-600" />
          <span className="font-medium text-gray-900">Assistant virtuel</span>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setIsMinimized(!isMinimized)}
            className="p-1 hover:bg-gray-100 rounded-lg"
          >
            {isMinimized ? (
              <ChevronUp className="h-5 w-5 text-gray-500" />
            ) : (
              <ChevronDown className="h-5 w-5 text-gray-500" />
            )}
          </button>
          <button
            onClick={onClose}
            className="p-1 hover:bg-gray-100 rounded-lg"
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>
      </div>

      {/* Messages */}
      {!isMinimized && (
        <div className="flex-1 overflow-y-auto p-4 space-y-4 h-[400px]">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`
                flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}
                animate-fadeIn
              `}
            >
              <div className={`
                max-w-[80%] rounded-lg p-3 whitespace-pre-wrap
                ${message.type === 'user'
                  ? 'bg-indigo-600 text-white'
                  : 'bg-gray-100 text-gray-900'
                }
              `}>
                {message.content}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Input */}
      {!isMinimized && (
        <div className="p-4 border-t border-gray-200">
          <div className="flex space-x-2">
            <input
              type="text"
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Tapez votre message..."
              className="flex-1 px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
            <button
              onClick={handleSendMessage}
              className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
            >
              Envoyer
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ChatTutorial;