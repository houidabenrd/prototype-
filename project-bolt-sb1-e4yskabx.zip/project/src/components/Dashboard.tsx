import React, { useState } from 'react';
import {
  Bell, Settings, UserCircle, Search, Building2, Receipt, Wallet2, 
  HelpCircle, FileText, FileSearch, MessageSquare, Calculator,
  Plus, ChevronDown, LogOut, CreditCard, Clock, ArrowRight,
  BarChart2, Calendar, Mail, Shield, Users2, Filter, Home,
  BookOpen, FileBarChart, Contact2, Building, ClipboardList,
  AlertCircle, RefreshCw, Megaphone, ShoppingCart, Info,
  CreditCard as PaymentIcon, Percent, Award, X, Check,
  DollarSign, AlertTriangle, Star, Brain, MessageCircle, Lock,
  Download, Sparkles, TrendingUp, Zap
} from 'lucide-react';
import RentalCycle from './RentalCycle';
import Communication from './Communication';
import Management from './Management';
import MemberSpace from './MemberSpace';
import SettingsPopup from './SettingsPopup';
import ProfilePopup from './ProfilePopup';
import BalancePopup from './BalancePopup';
import ChatTutorial from './ChatTutorial';

interface DashboardProps {
  onShowNews: () => void;
  onShowCalendar: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onShowNews, onShowCalendar }) => {
  // User state
  const [userName] = useState("Jean Dupont");
  const [balance, setBalance] = useState(150);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showInvoices, setShowInvoices] = useState(false);
  const [showBalancePopup, setShowBalancePopup] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Profil utilisateur
  const userProfile = {
    name: userName,
    email: "jean.dupont@exemple.com",
    phone: "+33 6 12 34 56 78",
    address: "123 Avenue des Champs-Élysées, 75008 Paris",
    company: "Immobilier Dupont SARL",
    joinDate: "15 janvier 2024",
    plan: "ON DEMAND"
  };

  const financeFeatures = [
    {
      id: 'loyers',
      icon: DollarSign,
      title: 'Collecte de loyers',
      description: 'Gestion des paiements de loyer',
      features: [
        'Paiements automatisés',
        'Suivi des retards',
        'Relances automatiques',
        'Historique complet'
      ]
    },
    {
      id: 'depenses',
      icon: Receipt,
      title: 'Dépenses',
      description: 'Suivi des dépenses et charges',
      features: [
        'Catégorisation automatique',
        'Notes de frais',
        'Rapports mensuels',
        'Export comptable'
      ]
    },
    {
      id: 'releve31',
      icon: FileText,
      title: 'Relevé 31',
      description: 'Génération automatique des relevés',
      features: [
        'Calcul automatique',
        'Validation des données',
        'Export PDF',
        'Archivage sécurisé'
      ]
    }
  ];

  const otherServices = [
    {
      id: 'conseil',
      icon: MessageCircle,
      title: 'Service conseil CORPIQ',
      description: 'Assistance et conseils personnalisés',
      features: [
        'Support prioritaire',
        'Conseils juridiques',
        'Assistance technique',
        'Réponse sous 24h'
      ]
    },
    {
      id: 'ia',
      icon: Brain,
      title: 'Analyse IA du parc immobilier',
      description: 'Analyse prédictive et recommandations',
      features: [
        'Prédictions de marché',
        'Optimisation des loyers',
        'Détection des risques',
        'Rapports personnalisés'
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header reste identique */}
      <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex items-center">
              <div className="flex items-center space-x-2">
                <div className="relative">
                  <Building2 className="h-8 w-8 text-indigo-600" />
                  <Shield className="h-4 w-4 text-indigo-800 absolute -bottom-1 -right-1" />
                </div>
                <div>
                  <div className="flex items-baseline">
                    <span className="text-xl font-bold bg-gradient-to-r from-indigo-600 to-indigo-800 bg-clip-text text-transparent">
                      AMS
                    </span>
                    <span className="text-xl font-bold text-gray-800 ml-1">CORPIQ</span>
                  </div>
                  <span className="text-xs text-gray-500 block -mt-1">On Demand</span>
                </div>
              </div>
            </div>

            {/* Barre de recherche */}
            <div className="flex-1 max-w-lg mx-8">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="block w-full pl-10 pr-3 py-2 border border-gray-200 rounded-lg text-sm placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                  placeholder="Rechercher un service..."
                />
              </div>
            </div>

            {/* Menu de droite */}
            <div className="flex items-center space-x-4">
              {/* Solde */}
              <button 
                onClick={() => setShowBalancePopup(true)}
                className="flex items-center space-x-2 px-3 py-2 rounded-lg hover:bg-gray-50"
              >
                <Wallet2 className="h-5 w-5 text-gray-400" />
                <div className="text-right">
                  <div className="text-sm text-gray-600">Solde</div>
                  <div className="font-semibold text-gray-900">{balance.toFixed(2)}$</div>
                </div>
              </button>

              {/* Paramètres */}
              <button
                onClick={() => setShowSettings(true)}
                className="p-2 text-gray-400 hover:text-gray-500 hover:bg-gray-50 rounded-lg"
              >
                <Settings className="h-6 w-6" />
              </button>

              {/* Menu utilisateur */}
              <div className="relative">
                <button
                  onClick={() => setShowUserMenu(!showUserMenu)}
                  className="flex items-center space-x-2 p-2 text-gray-700 hover:text-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 rounded-lg"
                >
                  <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center">
                    <span className="text-sm font-medium text-indigo-600">
                      {userName.split(' ').map(n => n[0]).join('')}
                    </span>
                  </div>
                  <ChevronDown className="h-4 w-4 text-gray-400" />
                </button>

                {showUserMenu && (
                  <div className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-xl ring-1 ring-black ring-opacity-5 z-50">
                    <div className="py-2">
                      <div className="px-4 py-3 border-b border-gray-100">
                        <p className="text-sm font-medium text-gray-900">{userName}</p>
                        <p className="text-xs text-gray-500 mt-1">{userProfile.email}</p>
                      </div>
                      <div className="py-1">
                        <button
                          onClick={() => {
                            setShowProfile(true);
                            setShowUserMenu(false);
                          }}
                          className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 w-full text-left"
                        >
                          <UserCircle className="h-4 w-4 mr-3 text-gray-400" />
                          Mon profil
                        </button>
                        <button
                          onClick={() => {
                            setShowInvoices(true);
                            setShowUserMenu(false);
                          }}
                          className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 w-full text-left"
                        >
                          <Receipt className="h-4 w-4 mr-3 text-gray-400" />
                          Mes factures
                        </button>
                      </div>
                      <div className="py-1 border-t border-gray-100">
                        <button className="flex items-center px-4 py-2 text-sm text-red-600 hover:bg-red-50 w-full text-left">
                          <LogOut className="h-4 w-4 mr-3" />
                          Déconnexion
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-12">
          {/* Sections principales */}
          <RentalCycle />
          <Communication />
          <Management />

          {/* Section Gestion financière */}
          <section>
            <div className="space-y-8">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Gestion financière</h2>
                <p className="mt-1 text-gray-600">Gérez vos finances et votre comptabilité</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {financeFeatures.map((feature) => (
                  <div
                    key={feature.id}
                    className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden opacity-75 feature-locked cursor-pointer group relative"
                  >
                    {/* VIP Badge */}
                    <div className="absolute top-3 right-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white text-xs px-2 py-1 rounded-full transform rotate-3 opacity-0 group-hover:opacity-100 transition-opacity z-10 flex items-center">
                      <Sparkles className="h-3 w-3 mr-1" />
                      Starter
                    </div>

                    <div className="p-6">
                      <div className="flex items-start space-x-4">
                        <div className="p-3 rounded-xl bg-gray-50 group-hover:bg-indigo-50 transition-colors">
                          <feature.icon className="h-6 w-6 text-gray-400 group-hover:text-indigo-600 transition-colors" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <h3 className="text-lg font-semibold text-gray-900">{feature.title}</h3>
                            <Lock className="h-5 w-5 text-gray-400 group-hover:text-indigo-600 transition-colors" />
                          </div>
                          <p className="mt-1 text-sm text-gray-600">{feature.description}</p>
                        </div>
                      </div>

                      <div className="mt-6 space-y-3">
                        {feature.features.map((featureItem, index) => (
                          <div key={index} className="flex items-center text-sm text-gray-600">
                            <Star className="h-4 w-4 mr-2 text-gray-300 group-hover:text-yellow-400 transition-colors" />
                            {featureItem}
                          </div>
                        ))}
                      </div>

                      <div className="mt-6 p-3 bg-gray-50 rounded-lg border border-gray-200 group-hover:bg-indigo-50 group-hover:border-indigo-100 transition-colors">
                        <div className="flex items-center text-sm text-gray-600 group-hover:text-indigo-600">
                          <Info className="h-4 w-4 mr-2" />
                          <span>Débloquez cette fonctionnalité avec le forfait Starter</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* Section Outils avancés */}
          <section>
            <div className="space-y-8">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Outils avancés</h2>
                <p className="mt-1 text-gray-600">Services et fonctionnalités avancés</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {otherServices.map((service) => (
                  <div
                    key={service.id}
                    className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden opacity-75 feature-locked cursor-pointer group relative"
                  >
                    {/* VIP Badge */}
                    <div className="absolute top-3 right-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white text-xs px-2 py-1 rounded-full transform rotate-3 opacity-0 group-hover:opacity-100 transition-opacity z-10 flex items-center">
                      <Sparkles className="h-3 w-3 mr-1" />
                      Starter
                    </div>

                    <div className="p-6">
                      <div className="flex items-start space-x-4">
                        <div className="p-3 rounded-xl bg-gray-50 group-hover:bg-indigo-50 transition-colors">
                          <service.icon className="h-6 w-6 text-gray-400 group-hover:text-indigo-600 transition-colors" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <h3 className="text-lg font-semibold text-gray-900">{service.title}</h3>
                            <Lock className="h-5 w-5 text-gray-400 group-hover:text-indigo-600 transition-colors" />
                          </div>
                          <p className="mt-1 text-sm text-gray-600">{service.description}</p>
                        </div>
                      </div>

                      <div className="mt-6 space-y-3">
                        {service.features.map((feature, index) => (
                          <div key={index} className="flex items-center text-sm text-gray-600">
                            <Star className="h-4 w-4 mr-2 text-gray-300 group-hover:text-yellow-400 transition-colors" />
                            {feature}
                          </div>
                        ))}
                      </div>

                      <div className="mt-6 p-3 bg-gray-50 rounded-lg border border-gray-200 group-hover:bg-indigo-50 group-hover:border-indigo-100 transition-colors">
                        <div className="flex items-center text-sm text-gray-600 group-hover:text-indigo-600">
                          <Info className="h-4 w-4 mr-2" />
                          <span>Débloquez cette fonctionnalité avec le forfait Starter</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* CTA Banner */}
              <div className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 rounded-xl p-8 text-white">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-2xl font-bold mb-2">
                      Débloquez tout le potentiel de votre gestion immobilière
                    </h3>
                    <p className="text-lg text-indigo-100">
                      Passez au forfait Starter pour seulement 199$/an et accédez à toutes les fonctionnalités
                    </p>
                  </div>
                  <button className="px-8 py-4 bg-white text-indigo-600 rounded-xl font-medium hover:bg-indigo-50 transition-colors flex items-center">
                    Passer au forfait Starter
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </button>
                </div>
              </div>
            </div>
          </section>

          <MemberSpace onShowNews={onShowNews} onShowCalendar={onShowCalendar} />
        </div>
      </main>

      {/* Popups */}
      <SettingsPopup
        isOpen={showSettings}
        onClose={() => setShowSettings(false)}
        plan="ON DEMAND"
      />

      <ProfilePopup
        isOpen={showProfile}
        onClose={() => setShowProfile(false)}
        user={userProfile}
      />

      <BalancePopup
        isOpen={showBalancePopup}
        onClose={() => setShowBalancePopup(false)}
        balance={balance}
        transactions={[]}
      />
    </div>
  );
};

export default Dashboard;