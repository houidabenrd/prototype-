import React, { useState } from 'react';
import { Mail, MessageSquare, Bell, ArrowRight, Star, Info, Lock, FileText, Sparkles } from 'lucide-react';
import StarterFeaturePopup from './StarterFeaturePopup';

const communicationServices = [
  {
    id: 'recommandes',
    icon: Mail,
    title: 'Recommandés électroniques',
    description: 'Envoyez des documents officiels avec preuve de réception',
    price: 14.99,
    starterPrice: 9.99,
    features: [
      'Preuve de réception légale',
      'Suivi en temps réel',
      'Archivage automatique',
      'Notifications automatiques'
    ],
    available: true
  },
  {
    id: 'messages',
    icon: MessageSquare,
    title: 'Envoyer un message',
    description: 'Communiquez avec vos locataires (copie par courriel)',
    features: [
      'Messages instantanés',
      'Historique des conversations',
      'Notifications par email',
      'Pièces jointes'
    ],
    available: false,
    starterFeature: true
  },
  {
    id: 'modeles',
    icon: FileText,
    title: 'Lettres',
    description: 'Bibliothèque de modèles de documents',
    features: [
      'Modèles juridiques',
      'Personnalisation facile',
      'Mise à jour automatique',
      'Export multi-formats'
    ],
    available: false,
    starterFeature: true
  }
];

const Communication = () => {
  const [showFeaturePopup, setShowFeaturePopup] = useState(false);
  const [selectedFeature, setSelectedFeature] = useState<typeof communicationServices[0] | null>(null);

  const handleFeatureClick = (service: typeof communicationServices[0]) => {
    if (!service.available) {
      setSelectedFeature(service);
      setShowFeaturePopup(true);
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Communication</h2>
          <p className="mt-1 text-gray-600">Gérez vos communications officielles en toute sécurité</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {communicationServices.map((service) => (
          <div
            key={service.id}
            onClick={() => handleFeatureClick(service)}
            className={`
              bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden
              ${!service.available ? 'feature-locked cursor-pointer' : ''}
              transition-all duration-300 hover:scale-[1.02] hover:shadow-md
              group relative
            `}
          >
            {/* VIP Badge */}
            {!service.available && (
              <div className="absolute top-3 right-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white text-xs px-2 py-1 rounded-full transform rotate-3 opacity-0 group-hover:opacity-100 transition-opacity z-10 flex items-center">
                <Sparkles className="h-3 w-3 mr-1" />
                Starter
              </div>
            )}

            <div className="p-6">
              <div className="flex items-start space-x-4">
                <div className={`p-3 rounded-xl ${service.available ? 'bg-indigo-50' : 'bg-gray-50 group-hover:bg-indigo-50 transition-colors'}`}>
                  <service.icon className={`h-6 w-6 ${service.available ? 'text-indigo-600' : 'text-gray-400 group-hover:text-indigo-600 transition-colors'}`} />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-semibold text-gray-900">{service.title}</h3>
                    {!service.available && (
                      <Lock className="h-5 w-5 text-gray-400 group-hover:text-indigo-600 transition-colors" />
                    )}
                  </div>
                  <p className="mt-1 text-sm text-gray-600">{service.description}</p>
                </div>
              </div>

              {service.available && (
                <div className="mt-4">
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-bold text-gray-400 group-hover:text-indigo-600 transition-colors">
                      {service.price}$
                    </span>
                    <div className="text-right">
                      <span className="text-sm text-gray-500">par envoi</span>
                      <div className="text-xs text-green-600">
                        {service.starterPrice}$ avec Starter
                      </div>
                    </div>
                  </div>
                </div>
              )}

              <div className="mt-6 space-y-3">
                {service.features.map((feature, index) => (
                  <div key={index} className="flex items-center text-sm text-gray-600">
                    <Star className={`h-4 w-4 mr-2 ${service.available ? 'text-yellow-400' : 'text-gray-300 group-hover:text-yellow-400 transition-colors'}`} />
                    {feature}
                  </div>
                ))}
              </div>

              {service.available ? (
                <button className="mt-6 w-full inline-flex items-center justify-center px-4 py-2 rounded-lg bg-indigo-600 text-white hover:bg-indigo-700 transition-colors">
                  <span>Envoyer un recommandé</span>
                  <ArrowRight className="ml-2 h-4 w-4" />
                </button>
              ) : (
                <div className="mt-6 p-3 bg-gray-50 rounded-lg border border-gray-200 group-hover:bg-indigo-50 group-hover:border-indigo-100 transition-colors">
                  <div className="flex items-center text-sm text-gray-600 group-hover:text-indigo-600">
                    <Info className="h-4 w-4 mr-2" />
                    <span>Débloquez cette fonctionnalité avec le forfait Starter</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Promo Banner */}
      <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div className="flex items-start space-x-4">
            <div className="p-3 bg-white/10 rounded-xl">
              <Info className="h-6 w-6 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-semibold">Optimisez vos communications !</h3>
              <p className="mt-1 text-indigo-100">
                Le forfait Starter vous donne accès à tous les outils de communication et des tarifs préférentiels sur les recommandés
              </p>
            </div>
          </div>
          <button className="px-6 py-3 bg-white text-indigo-600 rounded-lg font-medium hover:bg-indigo-50 transition-colors">
            Découvrir l'offre
          </button>
        </div>
      </div>

      {/* Starter Feature Popup */}
      {selectedFeature && (
        <StarterFeaturePopup
          isOpen={showFeaturePopup}
          onClose={() => setShowFeaturePopup(false)}
          feature={{
            title: selectedFeature.title,
            description: selectedFeature.description
          }}
        />
      )}
    </div>
  );
};

export default Communication;