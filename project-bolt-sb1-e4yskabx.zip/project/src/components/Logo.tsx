import React from 'react';
import { Building2, Shield } from 'lucide-react';

const Logo = () => {
  return (
    <div className="flex items-center space-x-2">
      <div className="relative">
        <Building2 className="h-8 w-8 text-indigo-600" />
        <Shield className="h-4 w-4 text-indigo-800 absolute -bottom-1 -right-1" />
      </div>
      <div>
        <div className="flex items-baseline">
          <span className="text-xl font-bold bg-gradient-to-r from-indigo-600 to-indigo-800 bg-clip-text text-transparent">
            AMS
          </span>
          <span className="text-xl font-bold text-gray-800 ml-1">CORPIQ</span>
        </div>
        <span className="text-xs text-gray-500 block -mt-1">
          Gestion Immobilière
        </span>
      </div>
    </div>
  );
};

export default Logo;