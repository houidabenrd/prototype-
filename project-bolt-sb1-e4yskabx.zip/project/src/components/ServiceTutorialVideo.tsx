import React from 'react';
import { X, Play, Info, ArrowLeft } from 'lucide-react';

interface ServiceTutorialVideoProps {
  service: {
    id: string;
    title: string;
    description: string;
  };
  onClose: () => void;
}

const getVideoUrl = (serviceId: string): string => {
  // Ces URLs sont des exemples - remplacez-les par vos vraies vidéos
  const videos: Record<string, string> = {
    annonces: 'https://www.youtube.com/embed/VIDEO_ID_ANNONCES',
    enquetes: 'https://www.youtube.com/embed/VIDEO_ID_ENQUETES',
    baux: 'https://www.youtube.com/embed/VIDEO_ID_BAUX',
    evenements: 'https://www.youtube.com/embed/VIDEO_ID_EVENEMENTS',
    formations: 'https://www.youtube.com/embed/VIDEO_ID_FORMATIONS',
    recommandes: 'https://www.youtube.com/embed/VIDEO_ID_RECOMMANDES'
  };
  
  return videos[serviceId] || '';
};

const ServiceTutorialVideo: React.FC<ServiceTutorialVideoProps> = ({ service, onClose }) => {
  const videoUrl = getVideoUrl(service.id);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl max-w-4xl w-full mx-4 overflow-hidden">
        {/* Header */}
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <button
                onClick={onClose}
                className="p-2 hover:bg-gray-100 rounded-lg text-gray-600 hover:text-gray-900 transition-colors"
              >
                <ArrowLeft className="h-5 w-5" />
              </button>
              <div className="p-2 bg-indigo-100 rounded-lg">
                <Play className="h-5 w-5 text-indigo-600" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-gray-900">
                  Tutoriel : {service.title}
                </h2>
                <p className="text-sm text-gray-500 mt-1">
                  {service.description}
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-500 transition-colors"
            >
              <X className="h-6 w-6" />
            </button>
          </div>
        </div>

        {/* Video Container */}
        <div className="aspect-video bg-black">
          <iframe
            src={videoUrl}
            className="w-full h-full"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          />
        </div>

        {/* Info Section */}
        <div className="p-6 bg-gray-50">
          <div className="flex items-start space-x-3">
            <Info className="h-5 w-5 text-indigo-600 mt-0.5" />
            <div>
              <h3 className="text-sm font-medium text-gray-900">
                Conseils d'utilisation
              </h3>
              <p className="mt-1 text-sm text-gray-600">
                Cette vidéo vous guide à travers les principales fonctionnalités du service.
                N'hésitez pas à la mettre en pause et à revenir en arrière si nécessaire.
              </p>
            </div>
          </div>
          
          {/* Bouton de retour en bas */}
          <div className="mt-4 flex justify-start">
            <button
              onClick={onClose}
              className="inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Retour à la sélection des services
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ServiceTutorialVideo;