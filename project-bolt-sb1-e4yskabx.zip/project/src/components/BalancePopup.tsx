import React, { useState } from 'react';
import { Wallet, Plus, History, AlertTriangle, DollarSign, CreditCard, ArrowRight, ArrowDown } from 'lucide-react';

interface Transaction {
  id: string;
  date: string;
  description: string;
  amount: number;
  type: 'credit' | 'debit';
  status: 'completed' | 'pending' | 'failed';
}

interface BalancePopupProps {
  isOpen: boolean;
  onClose: () => void;
  balance: number;
  transactions: Transaction[];
}

const predefinedAmounts = [20, 50, 100, 200];

const BalancePopup: React.FC<BalancePopupProps> = ({ isOpen, onClose, balance, transactions }) => {
  const [selectedAmount, setSelectedAmount] = useState<number | null>(null);
  const [customAmount, setCustomAmount] = useState('');
  const [showAddFunds, setShowAddFunds] = useState(false);

  if (!isOpen) return null;

  const handleAddFunds = () => {
    const amount = selectedAmount || Number(customAmount);
    console.log('Adding funds:', amount);
    // Logique d'ajout de fonds à implémenter
    setShowAddFunds(false);
  };

  const getStatusBadge = (status: Transaction['status']) => {
    switch (status) {
      case 'completed':
        return (
          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
            Complété
          </span>
        );
      case 'pending':
        return (
          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
            En cours
          </span>
        );
      case 'failed':
        return (
          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800">
            Échoué
          </span>
        );
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl max-w-2xl w-full mx-4 relative">
        {/* Header */}
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-indigo-100 rounded-lg">
                <Wallet className="h-6 w-6 text-indigo-600" />
              </div>
              <h2 className="text-xl font-bold text-gray-900">Votre solde</h2>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-500"
            >
              <ArrowDown className="h-6 w-6" />
            </button>
          </div>
        </div>

        {showAddFunds ? (
          <div className="p-6">
            <div className="mb-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Ajouter des crédits
              </h3>
              <p className="text-sm text-gray-600">
                Choisissez un montant ou entrez une valeur personnalisée
              </p>
            </div>

            {/* Montants prédéfinis */}
            <div className="grid grid-cols-2 gap-4 mb-6">
              {predefinedAmounts.map((amount) => (
                <button
                  key={amount}
                  onClick={() => {
                    setSelectedAmount(amount);
                    setCustomAmount('');
                  }}
                  className={`
                    p-4 rounded-lg border-2 text-center transition-all
                    ${selectedAmount === amount
                      ? 'border-indigo-600 bg-indigo-50'
                      : 'border-gray-200 hover:border-indigo-200'
                    }
                  `}
                >
                  <span className="text-xl font-bold text-gray-900">{amount}$</span>
                </button>
              ))}
            </div>

            {/* Montant personnalisé */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Ou entrez un montant personnalisé
              </label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                <input
                  type="number"
                  min="1"
                  value={customAmount}
                  onChange={(e) => {
                    setCustomAmount(e.target.value);
                    setSelectedAmount(null);
                  }}
                  className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="Entrez un montant"
                />
              </div>
            </div>

            {/* Actions */}
            <div className="flex space-x-4">
              <button
                onClick={() => setShowAddFunds(false)}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
              >
                Annuler
              </button>
              <button
                onClick={handleAddFunds}
                disabled={!selectedAmount && !customAmount}
                className="flex-1 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
              >
                <CreditCard className="h-4 w-4 mr-2" />
                Procéder au paiement
              </button>
            </div>
          </div>
        ) : (
          <div className="p-6">
            {/* Solde actuel */}
            <div className="text-center mb-8">
              <div className="inline-block p-4 bg-indigo-50 rounded-full mb-4">
                <DollarSign className="h-8 w-8 text-indigo-600" />
              </div>
              <h3 className="text-sm text-gray-600 mb-1">Solde disponible</h3>
              <div className="text-3xl font-bold text-gray-900">{balance.toFixed(2)}$</div>
            </div>

            {/* Alerte si solde bas */}
            {balance < 20 && (
              <div className="mb-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                <div className="flex items-start space-x-3">
                  <AlertTriangle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-sm font-medium text-yellow-800">
                      Solde faible
                    </h4>
                    <p className="text-sm text-yellow-700 mt-1">
                      Votre solde est bas. Ajoutez des crédits pour continuer à utiliser nos services.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Actions */}
            <div className="flex justify-center mb-8">
              <button
                onClick={() => setShowAddFunds(true)}
                className="inline-flex items-center px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
              >
                <Plus className="h-5 w-5 mr-2" />
                Ajouter des crédits
              </button>
            </div>

            {/* Historique des transactions */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900">
                  Historique des transactions
                </h3>
                <History className="h-5 w-5 text-gray-400" />
              </div>
              <div className="space-y-4">
                {transactions.map((transaction) => (
                  <div
                    key={transaction.id}
                    className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                  >
                    <div>
                      <p className="font-medium text-gray-900">
                        {transaction.description}
                      </p>
                      <div className="flex items-center space-x-3 mt-1">
                        <span className="text-sm text-gray-500">
                          {new Date(transaction.date).toLocaleDateString('fr-FR')}
                        </span>
                        {getStatusBadge(transaction.status)}
                      </div>
                    </div>
                    <span className={`
                      font-semibold
                      ${transaction.type === 'credit' ? 'text-green-600' : 'text-red-600'}
                    `}>
                      {transaction.type === 'credit' ? '+' : '-'}
                      {transaction.amount.toFixed(2)}$
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default BalancePopup;