import React from 'react';
import { TrendingUp, X, ArrowRight } from 'lucide-react';

interface UsageAlertBannerProps {
  totalSpent: number;
  onClose: () => void;
}

const UsageAlertBanner: React.FC<UsageAlertBannerProps> = ({ totalSpent, onClose }) => {
  const starterPrice = 199;
  const projectedYearlyCost = totalSpent * 12;
  const potentialSavings = projectedYearlyCost - starterPrice;

  return (
    <div className="bg-gradient-to-r from-amber-50 to-amber-100 border-b border-amber-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center">
              <TrendingUp className="h-5 w-5 text-amber-600" />
              <div className="ml-3">
                <p className="text-sm font-medium text-amber-900">
                  Vous utilisez trop les services à la pièce !
                </p>
                <p className="text-xs text-amber-800">
                  Projection annuelle : {projectedYearlyCost.toFixed(2)}$ • Économies potentielles : {potentialSavings.toFixed(2)}$
                </p>
              </div>
            </div>
            <button className="px-4 py-1.5 bg-amber-600 text-white text-sm font-medium rounded-lg hover:bg-amber-700 transition-colors flex items-center">
              Passer à Starter
              <ArrowRight className="ml-1.5 h-4 w-4" />
            </button>
          </div>
          <button
            onClick={onClose}
            className="text-amber-500 hover:text-amber-600"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default UsageAlertBanner;