import React from 'react';
import { X, Star, ArrowRight, Check, Sparkles, Shield, Clock } from 'lucide-react';

interface StarterFeaturePopupProps {
  isOpen: boolean;
  onClose: () => void;
  feature: {
    title: string;
    description: string;
  };
}

const StarterFeaturePopup: React.FC<StarterFeaturePopupProps> = ({ isOpen, onClose, feature }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl max-w-lg w-full mx-4 relative overflow-hidden">
        {/* Gradient Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/10 to-purple-500/10" />
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-500 z-10"
        >
          <X className="h-6 w-6" />
        </button>

        {/* Content */}
        <div className="relative p-8">
          <div className="flex items-center space-x-3 mb-6">
            <div className="p-2 bg-indigo-100 rounded-lg">
              <Star className="h-6 w-6 text-indigo-600" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-gray-900">
                Fonctionnalité Starter exclusive
              </h3>
              <p className="text-sm text-gray-600 mt-1">
                Débloquez {feature.title.toLowerCase()} et plus encore
              </p>
            </div>
          </div>

          <div className="space-y-6">
            {/* Feature Description */}
            <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-lg p-4 border border-indigo-100">
              <p className="text-indigo-900">
                {feature.description}
              </p>
            </div>

            {/* Benefits */}
            <div className="space-y-3">
              <h4 className="font-medium text-gray-900">
                Avantages du forfait Starter :
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {[
                  {
                    icon: Shield,
                    title: 'Accès illimité',
                    description: 'À toutes les fonctionnalités'
                  },
                  {
                    icon: Clock,
                    title: 'Traitement prioritaire',
                    description: 'Sans temps d\'attente'
                  },
                  {
                    icon: Check,
                    title: 'Prix réduits',
                    description: 'Sur les services à la pièce'
                  },
                  {
                    icon: Sparkles,
                    title: 'Fonctionnalités VIP',
                    description: 'Outils avancés exclusifs'
                  }
                ].map((benefit, index) => (
                  <div
                    key={index}
                    className="flex items-start space-x-3 p-3 bg-white rounded-lg border border-gray-200"
                  >
                    <div className="p-1.5 bg-indigo-50 rounded-lg">
                      <benefit.icon className="h-4 w-4 text-indigo-600" />
                    </div>
                    <div>
                      <div className="font-medium text-gray-900">{benefit.title}</div>
                      <div className="text-sm text-gray-500">{benefit.description}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Price Comparison */}
            <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg p-4 border border-green-100">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm text-green-800">Prix du forfait Starter</div>
                  <div className="text-2xl font-bold text-green-700">199$ / an</div>
                </div>
                <div className="text-right">
                  <div className="text-sm text-green-800">Économisez jusqu'à</div>
                  <div className="text-2xl font-bold text-green-700">50%</div>
                </div>
              </div>
            </div>

            {/* CTA Button */}
            <button className="w-full flex items-center justify-center px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all transform hover:scale-[1.02] font-medium">
              Passer au forfait Starter maintenant
              <ArrowRight className="ml-2 h-5 w-5" />
            </button>

            {/* Skip Link */}
            <button
              onClick={onClose}
              className="w-full text-center text-sm text-gray-500 hover:text-gray-700"
            >
              Continuer avec ON DEMAND
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StarterFeaturePopup;