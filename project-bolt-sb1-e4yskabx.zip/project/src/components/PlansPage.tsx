import React from 'react';
import { ArrowLeft, Check, Star, Info, Shield, Calendar, FileText, Users, Mail, Building2, ArrowRight, ChevronRight, Bell, Settings, MessageCircle, CreditCard, Brain, FileBarChart, Sparkles, TrendingUp, Zap, Clock } from 'lucide-react';

// ... (autres imports et interfaces restent identiques)

const PlansPage: React.FC<PlansPageProps> = ({ onSelectPlan, onBack }) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-indigo-50">
      {/* Header reste identique */}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Hero Section améliorée */}
        <div className="relative bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600 rounded-3xl overflow-hidden mb-16">
          <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1557683316-973673baf926?auto=format&fit=crop&q=80')] opacity-10 mix-blend-overlay" />
          <div className="relative px-8 py-12 text-center text-white">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Prêt à optimiser votre gestion immobilière ?
            </h1>
            <p className="text-xl text-indigo-100 max-w-3xl mx-auto mb-8">
              Rejoignez les milliers de propriétaires qui font confiance à CORPIQ pour simplifier leur gestion locative
            </p>
            <div className="flex flex-wrap justify-center gap-6 mb-8">
              <div className="flex items-center">
                <TrendingUp className="h-6 w-6 text-green-400 mr-2" />
                <span className="text-lg">Économisez jusqu'à 50%</span>
              </div>
              <div className="flex items-center">
                <Zap className="h-6 w-6 text-yellow-400 mr-2" />
                <span className="text-lg">Accès instantané</span>
              </div>
              <div className="flex items-center">
                <Clock className="h-6 w-6 text-blue-400 mr-2" />
                <span className="text-lg">Sans engagement</span>
              </div>
            </div>
            <div className="flex justify-center space-x-4">
              <button className="px-8 py-3 bg-white text-indigo-600 rounded-xl font-medium hover:bg-indigo-50 transition-colors transform hover:scale-105 duration-200">
                Comparer les forfaits
              </button>
              <button className="px-8 py-3 bg-indigo-500 text-white rounded-xl font-medium hover:bg-indigo-400 transition-colors transform hover:scale-105 duration-200">
                Essai gratuit 30 jours
              </button>
            </div>
          </div>
        </div>

        {/* Plans Grid amélioré */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={`
                relative bg-white rounded-2xl overflow-hidden
                transform transition-all duration-300 hover:scale-[1.02]
                ${plan.highlight 
                  ? 'ring-4 ring-indigo-600 shadow-2xl' 
                  : 'border-2 border-gray-200 shadow-lg hover:shadow-xl'
                }
              `}
            >
              {plan.highlight && (
                <div className="absolute top-0 left-0 right-0 bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-2 px-4 text-center">
                  <div className="flex items-center justify-center">
                    <Sparkles className="h-4 w-4 mr-2" />
                    <span className="font-medium">Le plus populaire</span>
                  </div>
                </div>
              )}

              <div className={`p-8 ${plan.highlight ? 'pt-16' : ''}`}>
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h2 className="text-3xl font-bold text-gray-900">{plan.name}</h2>
                    <p className="text-gray-600 mt-2">{plan.role}</p>
                  </div>
                  <div className="text-right">
                    {plan.price > 0 ? (
                      <>
                        <div className="text-4xl font-bold text-indigo-600">
                          {plan.price}$
                        </div>
                        <div className="text-gray-500">/an</div>
                      </>
                    ) : (
                      <div className="text-2xl font-medium text-indigo-600">Sur mesure</div>
                    )}
                  </div>
                </div>

                <p className="text-gray-600 mb-8 text-lg">{plan.description}</p>

                <div className="space-y-4 mb-8">
                  {plan.features.map((feature, index) => (
                    <div key={index} className="flex items-start">
                      <div className={`
                        p-1 rounded-full mr-3 flex-shrink-0 mt-1
                        ${plan.highlight ? 'bg-indigo-100' : 'bg-green-100'}
                      `}>
                        <Check className={`
                          h-4 w-4
                          ${plan.highlight ? 'text-indigo-600' : 'text-green-600'}
                        `} />
                      </div>
                      <span className="text-gray-700">{feature}</span>
                    </div>
                  ))}
                </div>

                <button
                  onClick={() => onSelectPlan({
                    name: plan.name,
                    price: plan.price,
                    role: plan.role
                  })}
                  className={`
                    w-full py-4 px-6 rounded-xl font-medium text-lg text-center
                    transition-all duration-300 transform hover:scale-105
                    ${plan.highlight
                      ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white hover:from-indigo-700 hover:to-purple-700 shadow-lg'
                      : plan.price > 0
                        ? 'bg-gray-900 text-white hover:bg-gray-800'
                        : 'bg-white text-indigo-600 border-2 border-indigo-600 hover:bg-indigo-50'
                    }
                  `}
                >
                  {plan.price > 0 ? (
                    <span className="flex items-center justify-center">
                      Commencer maintenant
                      <ArrowRight className="ml-2 h-5 w-5" />
                    </span>
                  ) : (
                    <span className="flex items-center justify-center">
                      Contacter un commercial
                      <ChevronRight className="ml-2 h-5 w-5" />
                    </span>
                  )}
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Le reste du composant reste identique */}
      </div>
    </div>
  );
};

export default PlansPage;