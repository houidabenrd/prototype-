import React from 'react';
import { X, Users2, Building2, MessageCircle, Book, Globe, Lock } from 'lucide-react';

interface SettingsPopupProps {
  isOpen: boolean;
  onClose: () => void;
  plan: string;
}

const SettingsPopup: React.FC<SettingsPopupProps> = ({ isOpen, onClose, plan }) => {
  if (!isOpen) return null;

  const isOnDemand = plan === 'ON DEMAND';

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl max-w-2xl w-full mx-4 relative">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-xl font-bold text-gray-900">Paramètres</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-500 transition-colors"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Team Management */}
          <div className={`relative ${isOnDemand ? 'opacity-50' : ''}`}>
            <div className="flex items-start space-x-4">
              <div className="p-2 bg-indigo-50 rounded-lg">
                <Users2 className="h-6 w-6 text-indigo-600" />
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-medium text-gray-900">Gérer mon équipe</h3>
                <p className="mt-1 text-sm text-gray-500">
                  Ajoutez des membres et gérez leurs permissions
                </p>
                {isOnDemand && (
                  <div className="mt-2 flex items-center text-sm text-orange-600">
                    <Lock className="h-4 w-4 mr-1" />
                    Cette fonctionnalité n'est pas disponible pour le forfait ON DEMAND
                  </div>
                )}
              </div>
              {!isOnDemand && (
                <button className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors text-sm">
                  Gérer
                </button>
              )}
            </div>
          </div>

          {/* Organization Management */}
          <div className={`relative ${isOnDemand ? 'opacity-50' : ''}`}>
            <div className="flex items-start space-x-4">
              <div className="p-2 bg-blue-50 rounded-lg">
                <Building2 className="h-6 w-6 text-blue-600" />
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-medium text-gray-900">Gérer mon organisation</h3>
                <p className="mt-1 text-sm text-gray-500">
                  Configurez les paramètres de votre organisation
                </p>
                {isOnDemand && (
                  <div className="mt-2 flex items-center text-sm text-orange-600">
                    <Lock className="h-4 w-4 mr-1" />
                    Cette fonctionnalité n'est pas disponible pour le forfait ON DEMAND
                  </div>
                )}
              </div>
              {!isOnDemand && (
                <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm">
                  Configurer
                </button>
              )}
            </div>
          </div>

          {/* Help & Support */}
          <div>
            <div className="flex items-start space-x-4">
              <div className="p-2 bg-emerald-50 rounded-lg">
                <MessageCircle className="h-6 w-6 text-emerald-600" />
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-medium text-gray-900">Aide et support</h3>
                <p className="mt-1 text-sm text-gray-500">
                  Contactez-nous par chat ou e-mail
                </p>
                <div className="mt-4 space-y-3">
                  <button className="w-full px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors text-sm">
                    Contacter le support
                  </button>
                  <button className="w-full px-4 py-2 border border-emerald-600 text-emerald-600 rounded-lg hover:bg-emerald-50 transition-colors text-sm">
                    Accéder à la FAQ
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Language Settings */}
          <div>
            <div className="flex items-start space-x-4">
              <div className="p-2 bg-purple-50 rounded-lg">
                <Globe className="h-6 w-6 text-purple-600" />
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-medium text-gray-900">Langue</h3>
                <p className="mt-1 text-sm text-gray-500">
                  Choisissez votre langue préférée
                </p>
                <select className="mt-2 w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500">
                  <option value="fr">Français</option>
                  <option value="en">English</option>
                  <option value="es">Español</option>
                </select>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SettingsPopup;