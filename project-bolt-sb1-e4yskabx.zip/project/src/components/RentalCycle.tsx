import React, { useState } from 'react';
import { Building, FileSearch, FileText, ArrowRight, Star, Info, Lock, Users, Calendar, AlertTriangle, Calculator, X, Sparkles } from 'lucide-react';
import StarterFeaturePopup from './StarterFeaturePopup';

const rentalServices = [
  {
    id: 'annonces',
    icon: Building,
    title: 'Annonces',
    description: 'Publiez et gérez vos offres de location',
    price: 29.99,
    starterPrice: 19.99,
    features: [
      'Publication multi-plateformes',
      'Photos HD illimitées',
      'Statistiques de consultation',
      'Gestion des demandes'
    ],
    available: true
  },
  {
    id: 'enquetes',
    icon: FileSearch,
    title: 'Enquêtes pré-location',
    description: 'Vérifiez les antécédents des locataires',
    price: 49.99,
    starterPrice: 29.99,
    features: [
      'Vérification de crédit',
      'Historique locatif',
      'Vérification d\'emploi',
      'Rapport détaillé'
    ],
    available: true,
    processingTime: 30 // minutes
  },
  {
    id: 'baux',
    icon: FileText,
    title: 'Baux électroniques',
    description: 'Créez et gérez vos baux en ligne',
    price: 39.99,
    starterPrice: 24.99,
    features: [
      'Modèles conformes à la loi',
      'Signature électronique',
      'Stockage sécurisé',
      'Suivi des modifications'
    ],
    available: true
  },
  {
    id: 'demandes',
    icon: Users,
    title: 'Demande de location',
    description: 'Gérez les demandes de location',
    features: [
      'Formulaire en ligne',
      'Validation d\'identité',
      'Suivi des demandes',
      'Notifications automatiques'
    ],
    available: false,
    starterFeature: true
  },
  {
    id: 'reconduction',
    icon: Calendar,
    title: 'Reconduction de bail',
    description: 'Gérez les renouvellements de bail',
    features: [
      'Avis automatiques',
      'Calcul des augmentations',
      'Suivi des réponses',
      'Historique des reconductions'
    ],
    available: false,
    starterFeature: true
  }
];

const RentalCycle = () => {
  const [showFeaturePopup, setShowFeaturePopup] = useState(false);
  const [selectedFeature, setSelectedFeature] = useState<typeof rentalServices[0] | null>(null);
  const [showProcessingAlert, setShowProcessingAlert] = useState(false);
  const [processingService, setProcessingService] = useState<string | null>(null);
  const [showCalculator, setShowCalculator] = useState(false);
  const [usageCount, setUsageCount] = useState(0);

  const handleFeatureClick = (service: typeof rentalServices[0]) => {
    if (!service.available) {
      setSelectedFeature(service);
      setShowFeaturePopup(true);
      return;
    }

    setUsageCount(prev => prev + 1);

    if (service.processingTime) {
      setProcessingService(service.id);
      setShowProcessingAlert(true);
      setTimeout(() => {
        setShowProcessingAlert(false);
        setProcessingService(null);
      }, 3000);
    }

    // Après 3 utilisations, montrer le calculateur
    if (usageCount >= 2) {
      setShowCalculator(true);
    }
  };

  const calculateYearlySavings = () => {
    const estimatedUsage = {
      annonces: 12, // Une par mois
      enquetes: 15, // Pour chaque nouveau locataire
      baux: 10 // Nouveaux baux et renouvellements
    };

    const onDemandCost = Object.entries(estimatedUsage).reduce((total, [service, count]) => {
      const serviceInfo = rentalServices.find(s => s.id === service);
      return total + (serviceInfo?.price || 0) * count;
    }, 0);

    const starterCost = 199; // Coût annuel du forfait Starter
    return onDemandCost - starterCost;
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Gestion locative</h2>
          <p className="mt-1 text-gray-600">Gérez efficacement vos locations de A à Z</p>
        </div>
      </div>

      {/* Alert pour le nombre d'utilisations */}
      {usageCount > 0 && (
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
          <div className="flex items-start">
            <AlertTriangle className="h-5 w-5 text-amber-600 mt-0.5" />
            <div className="ml-3">
              <h3 className="text-sm font-medium text-amber-800">
                Vous avez utilisé {usageCount} service{usageCount > 1 ? 's' : ''} payant{usageCount > 1 ? 's' : ''}
              </h3>
              <p className="mt-1 text-sm text-amber-700">
                Passez au forfait Starter pour économiser sur vos frais d'utilisation !
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Processing Alert */}
      {showProcessingAlert && processingService && (
        <div className="fixed top-4 right-4 bg-white rounded-lg shadow-lg border border-gray-200 p-4 z-50 animate-fadeIn">
          <div className="flex items-center space-x-3">
            <div className="animate-spin rounded-full h-4 w-4 border-2 border-indigo-600 border-t-transparent"></div>
            <div>
              <p className="text-sm font-medium text-gray-900">Traitement en cours...</p>
              <p className="text-xs text-gray-500">
                (Instantané avec le forfait Starter)
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Services Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {rentalServices.map((service) => (
          <div
            key={service.id}
            onClick={() => handleFeatureClick(service)}
            className={`
              bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden
              ${!service.available ? 'feature-locked cursor-pointer' : 'cursor-pointer'}
              transition-all duration-300 hover:scale-[1.02] hover:shadow-md
              group relative
            `}
          >
            {/* VIP Badge */}
            {!service.available && (
              <div className="absolute top-3 right-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white text-xs px-2 py-1 rounded-full transform rotate-3 opacity-0 group-hover:opacity-100 transition-opacity z-10 flex items-center">
                <Sparkles className="h-3 w-3 mr-1" />
                Starter
              </div>
            )}

            <div className="p-6">
              <div className="flex items-start space-x-4">
                <div className={`p-3 rounded-xl ${service.available ? 'bg-indigo-50' : 'bg-gray-50 group-hover:bg-indigo-50 transition-colors'}`}>
                  <service.icon className={`h-6 w-6 ${service.available ? 'text-indigo-600' : 'text-gray-400 group-hover:text-indigo-600 transition-colors'}`} />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-semibold text-gray-900">{service.title}</h3>
                    {!service.available && (
                      <Lock className="h-5 w-5 text-gray-400 group-hover:text-indigo-600 transition-colors" />
                    )}
                  </div>
                  <p className="mt-1 text-sm text-gray-600">{service.description}</p>
                </div>
              </div>

              {service.available && (
                <div className="mt-4">
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-bold text-gray-400 group-hover:text-indigo-600 transition-colors">
                      {service.price}$
                    </span>
                    <div className="text-right">
                      <span className="text-sm text-gray-500">par utilisation</span>
                      <div className="text-xs text-green-600">
                        {service.starterPrice}$ avec Starter
                      </div>
                    </div>
                  </div>
                </div>
              )}

              <div className="mt-6 space-y-3">
                {service.features.map((feature, index) => (
                  <div key={index} className="flex items-center text-sm text-gray-600">
                    <Star className={`h-4 w-4 mr-2 ${service.available ? 'text-yellow-400' : 'text-gray-300 group-hover:text-yellow-400 transition-colors'}`} />
                    {feature}
                  </div>
                ))}
              </div>

              {service.available ? (
                <button className="mt-6 w-full inline-flex items-center justify-center px-4 py-2 rounded-lg bg-indigo-600 text-white hover:bg-indigo-700 transition-colors">
                  <span>Utiliser maintenant</span>
                  <ArrowRight className="ml-2 h-4 w-4" />
                </button>
              ) : (
                <div className="mt-6 p-3 bg-gray-50 rounded-lg border border-gray-200 group-hover:bg-indigo-50 group-hover:border-indigo-100 transition-colors">
                  <div className="flex items-center text-sm text-gray-600 group-hover:text-indigo-600">
                    <Info className="h-4 w-4 mr-2" />
                    <span>Débloquez cette fonctionnalité avec le forfait Starter</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Calculateur d'économies */}
      {showCalculator && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl max-w-lg w-full mx-4 p-6">
            <div className="flex justify-between items-start mb-6">
              <div>
                <h3 className="text-xl font-bold text-gray-900">
                  Calculateur d'économies
                </h3>
                <p className="mt-1 text-sm text-gray-600">
                  Comparez vos coûts avec le forfait Starter
                </p>
              </div>
              <button
                onClick={() => setShowCalculator(false)}
                className="text-gray-400 hover:text-gray-500"
              >
                <X className="h-6 w-6" />
              </button>
            </div>

            <div className="space-y-6">
              <div className="bg-indigo-50 rounded-lg p-4">
                <div className="text-center">
                  <div className="text-sm text-indigo-600 font-medium">
                    Économies potentielles par an
                  </div>
                  <div className="text-3xl font-bold text-indigo-700 mt-1">
                    {calculateYearlySavings().toFixed(2)}$
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                  <span className="font-medium text-gray-700">Coût ON DEMAND estimé</span>
                  <span className="text-red-600 font-bold">
                    {(calculateYearlySavings() + 199).toFixed(2)}$
                  </span>
                </div>
                <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                  <span className="font-medium text-gray-700">Coût Starter annuel</span>
                  <span className="text-green-600 font-bold">199.00$</span>
                </div>
              </div>

              <button className="w-full py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors">
                Passer au forfait Starter
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Promo Banner */}
      <div className="bg-gradient-to-r from-purple-600 to-indigo-600 rounded-xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div className="flex items-start space-x-4">
            <div className="p-3 bg-white/10 rounded-xl">
              <Calculator className="h-6 w-6 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-semibold">Optimisez vos coûts !</h3>
              <p className="mt-1 text-indigo-100">
                Avec le forfait Starter à 199$/an, accédez à tous ces services en illimité et économisez jusqu'à 50%.
              </p>
            </div>
          </div>
          <button className="px-6 py-3 bg-white text-indigo-600 rounded-lg font-medium hover:bg-indigo-50 transition-colors">
            Découvrir l'offre
          </button>
        </div>
      </div>

      {/* Starter Feature Popup */}
      {selectedFeature && (
        <StarterFeaturePopup
          isOpen={showFeaturePopup}
          onClose={() => setShowFeaturePopup(false)}
          feature={{
            title: selectedFeature.title,
            description: selectedFeature.description
          }}
        />
      )}
    </div>
  );
};

export default RentalCycle;