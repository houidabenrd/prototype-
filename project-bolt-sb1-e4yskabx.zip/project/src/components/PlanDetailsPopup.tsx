import React from 'react';
import { X, Check, Star, Info, Bell, Settings, Users2, Building2, Newspaper, Calculator, MessageCircle, CreditCard, Sparkles, FileText, Search, Calendar, GraduationCap, Mail, MessageSquare, FileBarChart, PenTool as Tool, Archive, Brain } from 'lucide-react';

interface PlanDetailsPopupProps {
  isOpen: boolean;
  onClose: () => void;
  plan: {
    name: string;
    price: number;
  };
}

interface ModuleSection {
  title: string;
  icon: React.FC<{ className?: string }>;
  features: {
    name: string;
    included: boolean;
    payPerUse?: boolean;
    description?: string;
  }[];
}

const PlanDetailsPopup: React.FC<PlanDetailsPopupProps> = ({ isOpen, onClose, plan }) => {
  if (!isOpen) return null;

  const modules: ModuleSection[] = [
    {
      title: "Fonctionnalités de base",
      icon: Bell,
      features: [
        { name: "Notifications", included: true, description: "Restez informé de toutes vos activités" },
        { name: "Paramètres du compte", included: true, description: "Gérez vos préférences et configurations" }
      ]
    },
    {
      title: "Cycle de location",
      icon: Building2,
      features: [
        { name: "Demande de location", included: true, description: "Gestion des demandes (validation d'identité en supplément)" },
        { name: "Reconduction de bail", included: true },
        { name: "Annonces", included: true, payPerUse: true, description: "Publication d'annonces avec rabais membre" },
        { name: "Enquêtes pré-location", included: true, payPerUse: true },
        { name: "Bail électronique", included: true, payPerUse: true }
      ]
    },
    {
      title: "Espace membre",
      icon: Users2,
      features: [
        { name: "Répertoire des partenaires", included: true },
        { name: "Actualités", included: true },
        { name: "Événements", included: true, payPerUse: true },
        { name: "Formations", included: true, payPerUse: true },
        { name: "Service-conseil CORPIQ", included: true, payPerUse: true }
      ]
    },
    {
      title: "Gestion",
      icon: FileBarChart,
      features: [
        { name: "Gérer mon parc", included: true },
        { name: "Carnet d'adresses", included: true },
        { name: "Statistiques", included: true },
        { name: "Rapports", included: true },
        { name: "Travaux", included: true },
        { name: "Stockage et archives", included: true },
        { name: "Calculateur d'augmentation", included: true }
      ]
    },
    {
      title: "Communication",
      icon: MessageCircle,
      features: [
        { name: "Messagerie interne", included: true, description: "Avec copie par courriel" },
        { name: "Bibliothèque de modèles", included: true },
        { name: "Recommandé électronique", included: true, payPerUse: true },
        { name: "Messages textes", included: true, payPerUse: true }
      ]
    },
    {
      title: "Finance",
      icon: CreditCard,
      features: [
        { name: "Collecte de loyers", included: true },
        { name: "Gestion des dépenses", included: true },
        { name: "Relevé 31", included: true }
      ]
    },
    {
      title: "Automatisation",
      icon: Brain,
      features: [
        { name: "Règles d'affaires", included: true },
        { name: "Analyse IA du parc", included: true }
      ]
    }
  ];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 overflow-y-auto py-8">
      <div className="bg-white rounded-xl max-w-5xl w-full mx-4 relative">
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-gray-200 rounded-t-xl z-10">
          <div className="p-6">
            <button
              onClick={onClose}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-500"
            >
              <X className="h-6 w-6" />
            </button>
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">
                  Forfait {plan.name}
                </h2>
                <p className="mt-1 text-gray-600">
                  {plan.price}$ / an - Accès complet à la plateforme
                </p>
              </div>
              <button className="px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors">
                Souscrire
              </button>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 space-y-8">
          {/* Info Banner */}
          <div className="bg-indigo-50 rounded-xl p-4 border border-indigo-100">
            <div className="flex items-start space-x-3">
              <Info className="h-5 w-5 text-indigo-600 mt-0.5" />
              <div>
                <h3 className="font-medium text-indigo-900">
                  À propos de ce forfait
                </h3>
                <p className="mt-1 text-sm text-indigo-700">
                  Ce forfait vous donne accès à toutes les fonctionnalités de base et des tarifs préférentiels sur les services à la pièce.
                  Les services payants à la pièce bénéficient automatiquement du rabais membre.
                </p>
              </div>
            </div>
          </div>

          {/* Modules Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {modules.map((module, index) => (
              <div
                key={index}
                className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden"
              >
                <div className="p-6">
                  <div className="flex items-center space-x-3 mb-4">
                    <div className="p-2 bg-indigo-50 rounded-lg">
                      <module.icon className="h-5 w-5 text-indigo-600" />
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900">
                      {module.title}
                    </h3>
                  </div>
                  <ul className="space-y-3">
                    {module.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-start">
                        <div className="p-1 bg-green-100 rounded-full mr-3 flex-shrink-0 mt-1">
                          <Check className="h-3 w-3 text-green-600" />
                        </div>
                        <div>
                          <div className="flex items-center space-x-2">
                            <span className="text-sm text-gray-900">
                              {feature.name}
                            </span>
                            {feature.payPerUse && (
                              <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 border border-blue-200">
                                Rabais membre
                              </span>
                            )}
                          </div>
                          {feature.description && (
                            <p className="text-xs text-gray-500 mt-0.5">
                              {feature.description}
                            </p>
                          )}
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="sticky bottom-0 bg-white border-t border-gray-200 rounded-b-xl p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2 text-gray-600">
              <Star className="h-5 w-5 text-yellow-400" />
              <span>Accès illimité aux fonctionnalités de base</span>
            </div>
            <button className="px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors">
              Souscrire au forfait {plan.name}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PlanDetailsPopup;