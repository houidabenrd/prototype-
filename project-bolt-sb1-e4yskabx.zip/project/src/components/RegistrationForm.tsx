import React, { useState, useEffect } from 'react';
import { Mail, Lock, ArrowRight, ArrowLeft, Building2, Shield, Linkedin, AppWindow as WindowsLogo, Facebook } from 'lucide-react';

interface RegistrationFormProps {
  onRegisterSuccess: () => void;
  onBackToLogin: () => void;
  onShowPlanDetails: (plan: { name: string; price: number; role: string }) => void;
}

type RoleType = 'proprietaire-occupant' | 'proprietaire-investisseur' | 'entreprise' | 'gestionnaire' | 'courtier';

const smallPropertyRoles = [
  {
    id: 'proprietaire-occupant',
    title: 'Propriétaire Occupant',
    description: 'Vous habitez dans l\'un de vos immeubles',
    plan: {
      name: 'Starter',
      price: 199
    }
  },
  {
    id: 'proprietaire-investisseur',
    title: 'Propriétaire Investisseur',
    description: 'Vous possédez des immeubles locatifs',
    plan: {
      name: 'Starter',
      price: 299
    }
  }
];

const largePropertyRoles = [
  {
    id: 'entreprise',
    title: 'Entreprise immobilière',
    description: 'Vous représentez une société immobilière',
    plan: {
      name: 'Pro',
      price: 599
    }
  },
  {
    id: 'gestionnaire',
    title: 'Gestionnaire immobilier',
    description: 'Vous gérez des immeubles pour des propriétaires',
    plan: {
      name: 'Pro',
      price: 599
    }
  },
  {
    id: 'courtier',
    title: 'Courtier immobilier',
    description: 'Vous êtes un professionnel de l\'immobilier',
    plan: {
      name: 'Pro',
      price: 599
    }
  }
];

const RegistrationForm: React.FC<RegistrationFormProps> = ({ onRegisterSuccess, onBackToLogin, onShowPlanDetails }) => {
  const [step, setStep] = useState(1);
  const [email, setEmail] = useState('');
  const [confirmEmail, setConfirmEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isCORPIQMember, setIsCORPIQMember] = useState<boolean | null>(null);
  const [corpiqNumber, setCorpiqNumber] = useState('');
  const [showMembershipForm, setShowMembershipForm] = useState(false);
  const [hasMoreThan25Units, setHasMoreThan25Units] = useState<boolean | null>(null);
  const [selectedRole, setSelectedRole] = useState<RoleType | null>(null);
  const [errors, setErrors] = useState({
    email: '',
    confirmEmail: '',
    password: '',
    confirmPassword: '',
    unitsCount: '',
    role: ''
  });

  const availableRoles = hasMoreThan25Units ? largePropertyRoles : smallPropertyRoles;

  useEffect(() => {
    if (selectedRole) {
      const isRoleAvailable = availableRoles.some(role => role.id === selectedRole);
      if (!isRoleAvailable) {
        setSelectedRole(null);
      }
    }
  }, [hasMoreThan25Units]);

  const handleSocialLogin = (provider: string) => {
    console.log(`Connexion avec ${provider}`);
    setStep(3);
  };

  const validateEmailForm = () => {
    const newErrors = {
      email: '',
      confirmEmail: '',
      password: '',
      confirmPassword: '',
      unitsCount: '',
      role: ''
    };
    let isValid = true;

    if (email !== confirmEmail) {
      newErrors.confirmEmail = 'Les adresses email ne correspondent pas';
      isValid = false;
    }

    if (password !== confirmPassword) {
      newErrors.confirmPassword = 'Les mots de passe ne correspondent pas';
      isValid = false;
    }

    if (password.length < 8) {
      newErrors.password = 'Le mot de passe doit contenir au moins 8 caractères';
      isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  };

  const handleEmailFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateEmailForm()) {
      setStep(3);
    }
  };

  const handleJoinCORPIQChoice = (wantToJoin: boolean) => {
    if (!wantToJoin) {
      onRegisterSuccess();
    } else {
      setShowMembershipForm(true);
    }
  };

  const validateMembershipForm = () => {
    const newErrors = {
      ...errors,
      unitsCount: '',
      role: ''
    };
    let isValid = true;

    if (hasMoreThan25Units === null) {
      newErrors.unitsCount = 'Ce champ est requis';
      isValid = false;
    }

    if (!selectedRole) {
      newErrors.role = 'Veuillez sélectionner votre rôle';
      isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  };

  const handleMembershipSubmit = () => {
    if (validateMembershipForm()) {
      const selectedPlanInfo = [...smallPropertyRoles, ...largePropertyRoles].find(role => role.id === selectedRole);
      if (selectedPlanInfo) {
        onShowPlanDetails({
          name: selectedPlanInfo.plan.name,
          price: selectedPlanInfo.plan.price,
          role: selectedPlanInfo.title
        });
      }
    }
  };

  const renderJoinCORPIQCheck = () => (
    <div className="space-y-6">
      <h2 className="text-xl font-bold text-gray-900 text-center">
        Souhaitez-vous devenir membre de la CORPIQ ?
      </h2>

      <div className="space-y-6">
        {/* Boutons toujours visibles */}
        <div className="space-y-4">
          <button
            onClick={() => handleJoinCORPIQChoice(true)}
            className={`w-full px-4 py-3 rounded-lg border-2 text-left transition-all duration-200 ${
              showMembershipForm 
                ? 'border-indigo-500 bg-indigo-50'
                : 'hover:border-indigo-200 hover:bg-gray-50'
            }`}
          >
            <div className="font-medium text-gray-900">Oui, je souhaite devenir membre</div>
            <div className="text-sm text-gray-500">Accédez à tous les avantages membres</div>
          </button>

          <button
            onClick={() => handleJoinCORPIQChoice(false)}
            className={`w-full px-4 py-3 rounded-lg border-2 text-left transition-all duration-200 hover:border-indigo-200 hover:bg-gray-50 ${
              showMembershipForm ? 'opacity-50' : ''
            }`}
            disabled={showMembershipForm}
          >
            <div className="font-medium text-gray-900">Non, pas maintenant</div>
            <div className="text-sm text-gray-500">Continuer avec le forfait ON DEMAND</div>
          </button>
        </div>

        {/* Formulaire d'informations sur le patrimoine */}
        {showMembershipForm && (
          <div className="space-y-6 border-t border-gray-200 pt-6">
            <h3 className="text-lg font-medium text-gray-900">
              Informations sur votre patrimoine
            </h3>
            
            {/* Nombre de logements - Nouveaux boutons de choix */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Combien de logements possédez-vous ?
              </label>
              <div className="grid grid-cols-2 gap-4">
                <button
                  type="button"
                  onClick={() => setHasMoreThan25Units(false)}
                  className={`
                    p-4 rounded-lg border-2 text-center transition-all duration-200
                    ${hasMoreThan25Units === false
                      ? 'border-indigo-500 bg-indigo-50'
                      : 'border-gray-200 hover:border-indigo-200 hover:bg-gray-50'
                    }
                  `}
                >
                  <div className="font-medium text-gray-900">25 ou moins</div>
                  <div className="text-sm text-gray-500">Forfait Starter</div>
                </button>

                <button
                  type="button"
                  onClick={() => setHasMoreThan25Units(true)}
                  className={`
                    p-4 rounded-lg border-2 text-center transition-all duration-200
                    ${hasMoreThan25Units === true
                      ? 'border-indigo-500 bg-indigo-50'
                      : 'border-gray-200 hover:border-indigo-200 hover:bg-gray-50'
                    }
                  `}
                >
                  <div className="font-medium text-gray-900">Plus de 25</div>
                  <div className="text-sm text-gray-500">Forfait Pro</div>
                </button>
              </div>
            </div>

            {/* Rôle - affiché uniquement après la sélection du nombre de logements */}
            {hasMoreThan25Units !== null && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  Quel est votre rôle dans le secteur de l'immobilier ?
                </label>
                <div className="space-y-3">
                  {availableRoles.map((role) => (
                    <button
                      key={role.id}
                      type="button"
                      onClick={() => setSelectedRole(role.id as RoleType)}
                      className={`w-full px-4 py-3 rounded-lg border-2 text-left transition-all duration-200 ${
                        selectedRole === role.id
                          ? 'border-indigo-500 bg-indigo-50'
                          : 'border-gray-200 hover:border-indigo-200 hover:bg-gray-50'
                      }`}
                    >
                      <div className="font-medium text-gray-900">{role.title}</div>
                      <div className="text-sm text-gray-500">{role.description}</div>
                    </button>
                  ))}
                </div>
                {errors.role && (
                  <p className="mt-1 text-sm text-red-600">{errors.role}</p>
                )}
              </div>
            )}

            {/* Actions */}
            <div className="flex justify-end pt-6">
              <button
                onClick={handleMembershipSubmit}
                disabled={hasMoreThan25Units === null || !selectedRole}
                className={`flex items-center px-6 py-2 rounded-lg transition-colors ${
                  hasMoreThan25Units === null || !selectedRole
                    ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                    : 'bg-indigo-600 text-white hover:bg-indigo-700'
                }`}
              >
                Voir mon forfait suggéré
                <ArrowRight className="h-4 w-4 ml-2" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className="bg-white/90 backdrop-blur-xl rounded-2xl shadow-xl p-8 border border-gray-100 w-full max-w-xl mx-auto">
      {step === 1 && (
        <div className="space-y-8">
          <div className="space-y-4">
            <button
              onClick={() => handleSocialLogin('Microsoft')}
              className="w-full flex items-center justify-center px-6 py-3 bg-gray-800 text-white rounded-lg hover:bg-gray-900 transition-colors"
            >
              <WindowsLogo className="h-5 w-5 mr-3" />
              Continuer avec Microsoft
            </button>

            <button
              onClick={() => handleSocialLogin('LinkedIn')}
              className="w-full flex items-center justify-center px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Linkedin className="h-5 w-5 mr-3" />
              Continuer avec LinkedIn
            </button>

            <button
              onClick={() => handleSocialLogin('Facebook')}
              className="w-full flex items-center justify-center px-6 py-3 bg-blue-700 text-white rounded-lg hover:bg-blue-800 transition-colors"
            >
              <Facebook className="h-5 w-5 mr-3" />
              Continuer avec Facebook
            </button>
          </div>

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-300"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-white text-gray-500">Ou</span>
            </div>
          </div>

          <button
            onClick={() => setStep(1.5)}
            className="w-full flex items-center justify-center px-6 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
          >
            Continuer avec un email
          </button>
        </div>
      )}

      {step === 1.5 && (
        <div className="space-y-6">
          <form onSubmit={handleEmailFormSubmit} className="space-y-4">
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                Adresse email
              </label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Mail className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="email"
                  id="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="vous@exemple.com"
                />
              </div>
              {errors.email && (
                <p className="mt-1 text-sm text-red-600">{errors.email}</p>
              )}
            </div>

            <div>
              <label htmlFor="confirmEmail" className="block text-sm font-medium text-gray-700">
                Confirmez votre email
              </label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Mail className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="email"
                  id="confirmEmail"
                  required
                  value={confirmEmail}
                  onChange={(e) => setConfirmEmail(e.target.value)}
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="vous@exemple.com"
                />
              </div>
              {errors.confirmEmail && (
                <p className="mt-1 text-sm text-red-600">{errors.confirmEmail}</p>
              )}
            </div>

            <div>
              <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                Mot de passe
              </label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Lock className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="password"
                  id="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="••••••••"
                />
              </div>
              {errors.password && (
                <p className="mt-1 text-sm text-red-600">{errors.password}</p>
              )}
            </div>

            <div>
              <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700">
                Confirmez votre mot de passe
              </label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Lock className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="password"
                  id="confirmPassword"
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="••••••••"
                />
              </div>
              {errors.confirmPassword && (
                <p className="mt-1 text-sm text-red-600">{errors.confirmPassword}</p>
              )}
            </div>

            <button
              type="submit"
              className="w-full flex items-center justify-center px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
            >
              Continuer
              <ArrowRight className="ml-2 h-5 w-5" />
            </button>
          </form>
        </div>
      )}

      {step === 2 && (
        <div className="space-y-6">
          <h2 className="text-xl font-bold text-gray-900 text-center">
            Êtes-vous membre de la CORPIQ ?
          </h2>
          <div className="space-y-4">
            <button
              onClick={() => {
                setIsCORPIQMember(true);
                setStep(2.5);
              }}
              className="w-full px-4 py-3 rounded-lg border-2 text-left transition-all duration-200 hover:border-indigo-200 hover:bg-gray-50"
            >
              <div className="font-medium text-gray-900">Oui, je suis membre CORPIQ</div>
              <div className="text-sm text-gray-500">J'ai une carte CORPIQ</div>
            </button>

            <button
              onClick={() => {
                setIsCORPIQMember(false);
                setStep(3);
              }}
              className="w-full px-4 py-3 rounded-lg border-2 text-left transition-all duration-200 hover:border-indigo-200 hover:bg-gray-50"
            >
              <div className="font-medium text-gray-900">Non, je ne suis pas membre</div>
              <div className="text-sm text-gray-500">Je souhaite créer un compte</div>
            </button>
          </div>
        </div>
      )}

      {step === 3 && renderJoinCORPIQCheck()}

      {step === 2.5 && (
        <div className="space-y-6">
          <h2 className="text-xl font-bold text-gray-900 text-center">
            Entrez votre numéro de membre CORPIQ
          </h2>
          <div>
            <input
              type="text"
              value={corpiqNumber}
              onChange={(e) => setCorpiqNumber(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              placeholder="Numéro de membre"
            />
          </div>
          <button
            onClick={() => onRegisterSuccess()}
            className="w-full flex items-center justify-center px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
          >
            Continuer
            <ArrowRight className="ml-2 h-5 w-5" />
          </button>
        </div>
      )}
    </div>
  );
};

export default RegistrationForm;