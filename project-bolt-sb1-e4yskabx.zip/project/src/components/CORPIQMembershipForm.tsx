import React, { useState, useEffect } from 'react';
import { Building2, ArrowLeft, ArrowRight, Star } from 'lucide-react';

interface CORPIQMembershipFormProps {
  onSubmit: () => void;
  onBack: () => void;
  onShowPlanDetails: (plan: { name: string; price: number; role: string }) => void;
}

type RoleType = 'proprietaire-occupant' | 'proprietaire-investisseur' | 'entreprise' | 'gestionnaire' | 'courtier';

const smallPropertyRoles = [
  {
    id: 'proprietaire-occupant',
    title: 'Propriétaire Occupant',
    description: 'Vous habitez dans l\'un de vos immeubles',
    plan: {
      name: 'Starter',
      price: 199
    }
  },
  {
    id: 'proprietaire-investisseur',
    title: 'Propriétaire Investisseur',
    description: 'Vous possédez des immeubles locatifs',
    plan: {
      name: 'Starter',
      price: 299
    }
  }
];

const largePropertyRoles = [
  {
    id: 'entreprise',
    title: 'Entreprise immobilière',
    description: 'Vous représentez une société immobilière',
    plan: {
      name: 'Pro',
      price: 599
    }
  },
  {
    id: 'gestionnaire',
    title: 'Gestionnaire immobilier',
    description: 'Vous gérez des immeubles pour des propriétaires',
    plan: {
      name: 'Pro',
      price: 599
    }
  },
  {
    id: 'courtier',
    title: 'Courtier immobilier',
    description: 'Vous êtes un professionnel de l\'immobilier',
    plan: {
      name: 'Pro',
      price: 599
    }
  }
];

const CORPIQMembershipForm: React.FC<CORPIQMembershipFormProps> = ({ onSubmit, onBack, onShowPlanDetails }) => {
  const [unitsCount, setUnitsCount] = useState('');
  const [selectedRole, setSelectedRole] = useState<RoleType | null>(null);
  const [errors, setErrors] = useState({
    unitsCount: '',
    role: ''
  });

  // Détermine quels rôles afficher en fonction du nombre de logements
  const availableRoles = parseInt(unitsCount) >= 25 ? largePropertyRoles : smallPropertyRoles;

  // Réinitialise le rôle sélectionné si le nombre de logements change et que le rôle n'est plus disponible
  useEffect(() => {
    if (selectedRole) {
      const isRoleAvailable = availableRoles.some(role => role.id === selectedRole);
      if (!isRoleAvailable) {
        setSelectedRole(null);
      }
    }
  }, [unitsCount]);

  const validateForm = () => {
    const newErrors = {
      unitsCount: '',
      role: ''
    };
    let isValid = true;

    if (!unitsCount) {
      newErrors.unitsCount = 'Ce champ est requis';
      isValid = false;
    } else if (parseInt(unitsCount) < 1) {
      newErrors.unitsCount = 'Le nombre doit être supérieur à 0';
      isValid = false;
    }

    if (!selectedRole) {
      newErrors.role = 'Veuillez sélectionner votre rôle';
      isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      const selectedPlanInfo = [...smallPropertyRoles, ...largePropertyRoles].find(role => role.id === selectedRole);
      if (selectedPlanInfo) {
        onShowPlanDetails({
          name: selectedPlanInfo.plan.name,
          price: selectedPlanInfo.plan.price,
          role: selectedPlanInfo.title
        });
      }
    }
  };

  const isSubmitDisabled = !unitsCount;

  // Trouve le plan correspondant au rôle sélectionné
  const selectedPlan = selectedRole && 
    [...smallPropertyRoles, ...largePropertyRoles].find(role => role.id === selectedRole)?.plan;

  const selectedRoleTitle = selectedRole &&
    [...smallPropertyRoles, ...largePropertyRoles].find(role => role.id === selectedRole)?.title;

  return (
    <div className="bg-white/90 backdrop-blur-xl rounded-2xl shadow-xl p-8 border border-gray-100 w-full max-w-xl mx-auto">
      <div className="space-y-6">
        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold text-gray-900">Informations sur votre patrimoine</h2>
          <p className="mt-2 text-gray-600">Ces informations nous permettront de mieux vous accompagner</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Nombre de logements */}
          <div>
            <label htmlFor="unitsCount" className="block text-sm font-medium text-gray-700">
              Combien de logements possédez-vous ?
            </label>
            <div className="mt-1 relative rounded-md shadow-sm">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Building2 className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="number"
                id="unitsCount"
                min="1"
                value={unitsCount}
                onChange={(e) => setUnitsCount(e.target.value)}
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
                placeholder="Nombre de logements"
              />
            </div>
            {errors.unitsCount && (
              <p className="mt-1 text-sm text-red-600">{errors.unitsCount}</p>
            )}
          </div>

          {/* Rôle */}
          {unitsCount && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Quel est votre rôle dans le secteur de l'immobilier ?
              </label>
              <div className="space-y-3">
                {availableRoles.map((role) => (
                  <button
                    key={role.id}
                    type="button"
                    onClick={() => setSelectedRole(role.id as RoleType)}
                    className={`w-full px-4 py-3 rounded-lg border-2 text-left transition-all duration-200 ${
                      selectedRole === role.id
                        ? 'border-indigo-500 bg-indigo-50'
                        : 'border-gray-200 hover:border-indigo-200 hover:bg-gray-50'
                    }`}
                  >
                    <div className="font-medium text-gray-900">{role.title}</div>
                    <div className="text-sm text-gray-500">{role.description}</div>
                  </button>
                ))}
              </div>
              {errors.role && (
                <p className="mt-1 text-sm text-red-600">{errors.role}</p>
              )}
            </div>
          )}

          {/* Plan suggéré */}
          {selectedRole && selectedPlan && (
            <div className="mt-6 p-4 bg-indigo-50 rounded-lg border border-indigo-100">
              <div className="flex items-start space-x-3">
                <div className="p-2 bg-indigo-100 rounded-lg">
                  <Star className="h-5 w-5 text-indigo-600" />
                </div>
                <div>
                  <h3 className="font-medium text-indigo-900">
                    Forfait suggéré : {selectedPlan.name}
                  </h3>
                  <p className="text-sm text-indigo-700 mt-1">
                    {selectedPlan.price}$ / an - Accès illimité à tous les services
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex justify-between pt-6">
            <button
              type="button"
              onClick={onBack}
              className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 hover:text-gray-900"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Retour
            </button>
            <button
              type="submit"
              disabled={isSubmitDisabled}
              className={`flex items-center px-6 py-2 rounded-lg transition-colors ${
                isSubmitDisabled
                  ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  : 'bg-indigo-600 text-white hover:bg-indigo-700'
              }`}
            >
              Voir mon forfait suggéré
              <ArrowRight className="h-4 w-4 ml-2" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CORPIQMembershipForm;